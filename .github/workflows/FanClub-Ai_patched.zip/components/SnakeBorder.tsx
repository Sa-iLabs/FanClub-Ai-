import React from 'react';

interface SnakeBorderProps {
  children: React.ReactNode;
  snakeColor: string;
  className?: string;
  cornerRadius?: string;
  glowOpacity?: number;
  borderWidth?: string;
}

const SnakeBorder: React.FC<SnakeBorderProps> = ({ 
  children, 
  snakeColor, 
  className = '', 
  cornerRadius = 'rounded-xl',
  glowOpacity = 0.6,
  borderWidth = 'p-[2px]'
}) => {
  return (
    <div className={`relative group overflow-hidden ${cornerRadius} ${borderWidth} ${className} shadow-md transition-all duration-300 hover:shadow-lg hover:scale-[1.02]`}>
      {/* Snake Gradient */}
      <div 
        className="absolute inset-[-200%] animate-spin-slow"
        style={{ 
          background: `conic-gradient(from 0deg at 50% 50%, transparent 0%, transparent 70%, ${snakeColor} 100%)`,
          opacity: glowOpacity
        }}
      />
      
      {/* Inner Content Background (clips the snake to just the border) */}
      <div className={`relative h-full w-full ${cornerRadius} bg-inherit z-10 overflow-hidden`}>
        {children}
      </div>
    </div>
  );
};

export default SnakeBorder;