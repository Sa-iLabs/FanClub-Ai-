import React, { useState } from 'react';
import { AlertTriangle, Lock } from 'lucide-react';

interface ConsentModalProps {
  isOpen: boolean;
  onConfirm: (dob: string) => void;
  onCancel: () => void;
  targetLevel: number;
}

const ConsentModal: React.FC<ConsentModalProps> = ({ isOpen, onConfirm, onCancel, targetLevel }) => {
  const [dob, setDob] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-neutral-900 border border-red-900 rounded-xl max-w-md w-full p-6 text-white shadow-2xl shadow-red-900/20">
        <div className="flex items-center gap-3 mb-4 text-red-500">
          <AlertTriangle size={32} />
          <h2 className="text-xl font-bold uppercase tracking-wider">Restricted Content</h2>
        </div>
        
        <p className="mb-4 text-neutral-300">
          You are attempting to access Intensity Level <strong>{targetLevel}</strong>. 
          This mode generates explicit, unfiltered content intended strictly for adults.
        </p>

        <div className="bg-red-950/30 p-4 rounded-lg border border-red-900/50 mb-6">
          <h3 className="text-sm font-bold text-red-400 mb-2 flex items-center gap-2">
            <Lock size={14} /> Verification Required
          </h3>
          <p className="text-xs text-red-200 mb-3">
            Please confirm your Date of Birth to proceed. By continuing, you certify that you are 18+ and consent to viewing generated adult content.
          </p>
          <input 
            type="date" 
            className="w-full bg-neutral-950 border border-red-800 rounded p-2 text-white"
            value={dob}
            onChange={(e) => setDob(e.target.value)}
          />
        </div>

        <div className="flex gap-3 justify-end">
          <button 
            onClick={onCancel}
            className="px-4 py-2 rounded text-neutral-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={() => onConfirm(dob)}
            disabled={!dob}
            className="px-6 py-2 bg-red-700 hover:bg-red-600 text-white font-bold rounded shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            I Consent & Enter
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConsentModal;