
import React, { useState, useEffect, useRef } from 'react';
import SnakeCard from './SnakeCard';
import { Send, XCircle, Sparkles, Copy, Check, Bot, Volume2 } from 'lucide-react';
import TypingIndicator from './TypingIndicator';
import { apiService } from '../services/api';
import { UserSettings } from '../types';

interface NeuralAssistantProps {
  theme: any;
  onClose: () => void;
  settings: UserSettings;
  currentPersona: string;
  currentIntensity: number;
}

const NeuralAssistant: React.FC<NeuralAssistantProps> = ({ settings, onClose, currentPersona, currentIntensity }) => {
  const [messages, setMessages] = useState<{id: string, role: 'user' | 'model', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMsg = input;
    const userMsgId = Date.now().toString();
    setMessages(prev => [...prev, { id: userMsgId, role: 'user', text: userMsg }]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await apiService.sendPrompt(
        settings.userId,
        currentPersona,
        currentIntensity,
        `Neural Dev Query: ${userMsg}. (Respond as SA-iLabs Assistant using Gemini 3 Pro)`,
        undefined,
        undefined,
        settings.personaConfig?.[currentPersona as any]
      );

      if (res.status === 'ok' && res.reply) {
        const modelMsgId = (Date.now() + 1).toString();
        setMessages(prev => [...prev, { id: modelMsgId, role: 'model', text: res.reply! }]);
        if (settings.enableAutoVoice) {
          apiService.generateSpeech(res.reply!, settings, currentIntensity);
        }
      } else {
        throw new Error(res.reply || "Neural Uplink Interrupted");
      }
    } catch (err: any) {
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: `Node Fault: ${err.message}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  return (
    <div className="flex flex-col h-full w-full animate-fade-in">
       <SnakeCard snakeColor="#8b5cf6" innerClassName="bg-slate-950 text-white flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-violet-900/50 bg-violet-950/20">
             <div className="flex items-center gap-3">
               <div className="p-2 bg-violet-900/30 rounded-lg">
                 <Sparkles className="text-violet-400" size={20} />
               </div>
               <div>
                 <h2 className="font-bold text-lg leading-none tracking-tight">🌐 SA-iLabs Gemini</h2>
                 <p className="text-[10px] uppercase tracking-wider text-violet-400 font-semibold mt-0.5">Gemini 3 Pro Core</p>
               </div>
             </div>
             <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
               <XCircle size={20} className="text-slate-400 hover:text-white" />
             </button>
          </div>

          <div className="flex-1 overflow-hidden relative flex flex-col p-4">
            <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-hide pb-4">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full text-slate-500 opacity-60">
                  <Bot size={48} className="mb-4" />
                  <p className="text-sm font-medium">Gemini Neural Link Active</p>
                </div>
              )}
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}>
                  <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm shadow-sm relative group ${m.role === 'user' ? 'bg-violet-600 text-white rounded-tr-none' : 'bg-slate-800 text-slate-200 border border-slate-700/50 rounded-tl-none'}`}>
                     <div className="leading-relaxed whitespace-pre-wrap">{m.text}</div>
                     <div className="mt-2 pt-1.5 border-t border-white/10 flex justify-between">
                        <button onClick={() => apiService.generateSpeech(m.text, settings, currentIntensity)} className="p-1 rounded hover:bg-white/10 transition-colors text-white/40 hover:text-white">
                          <Volume2 size={10} />
                        </button>
                        <button onClick={() => copyToClipboard(m.text, m.id)} className="p-1 rounded hover:bg-white/10 transition-colors flex items-center gap-1 text-white/60 hover:text-white">
                          {copiedId === m.id ? <Check size={10} /> : <Copy size={10} />}
                        </button>
                     </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start animate-slide-up">
                  <div className="bg-slate-800 text-slate-200 border border-slate-700/50 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm">
                    <TypingIndicator />
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-2 flex gap-2">
              <input 
                className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-all text-sm shadow-inner"
                placeholder="Query Gemini node..."
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
              />
              <button onClick={handleSendMessage} disabled={!input.trim() || isLoading} className="p-3 bg-violet-600 rounded-xl text-white hover:bg-violet-500 transition-colors shadow-lg active:scale-95">
                <Send size={18} />
              </button>
            </div>
          </div>
       </SnakeCard>
    </div>
  );
};

export default NeuralAssistant;
