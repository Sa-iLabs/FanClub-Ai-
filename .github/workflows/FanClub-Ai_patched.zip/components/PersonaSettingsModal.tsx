
import React, { useState } from 'react';
import SnakeCard from './SnakeCard';
import { X, Save, Sliders, User, Heart, Zap, MessageCircle, AlertCircle, ChevronUp, ChevronDown, ImageIcon, RefreshCw, Eye, Info, Check } from 'lucide-react';
import { PersonaAttributes, PersonaType } from '../types';
import { apiService } from '../services/api';

const DEFAULT_ATTRS: PersonaAttributes = {
  friendly: 10, kind: 10, strong: 0, annoyed: 0,
  kinky: 10, sexy: 10, amorous: 10, horny: 10,
  forward: 10, cursing: 10, naughty: 10, foulLanguage: 10,
  dirtyTalk: 10, seductive: 10, approachable: 10, direct: 10, secretive: 0,
  rude: 0, needy: 10, dominant: 0, submissive: 10,
  dynamic: 'partner', gender: 'female', orientation: 'straight', age: 24
};

const ATTRIBUTE_DESCS: Record<keyof PersonaAttributes, string> = {
  friendly: "Neural warmth and openness in communication.",
  kind: "Empathetic processing and supportive language levels.",
  strong: "Assertive confidence and decisive speech patterns.",
  annoyed: "Irritability and temper threshold in responses.",
  kinky: "Adventurous roleplay divergence and fetish interest.",
  sexy: "Physical attraction focus and flirtatious frequency.",
  amorous: "Depth of romantic affection and emotional longing.",
  horny: "Directness and frequency of sexual intent.",
  forward: "Interaction initiative and lack of social hesitation.",
  cursing: "Frequency of mild to moderate profanity usage.",
  naughty: "Suggestive behavior and playful deviance patterns.",
  foulLanguage: "Raw vulgarity and explicit lexicon activation.",
  dirtyTalk: "Erotic description proficiency and vulgar detail.",
  seductive: "Persuasion power and charismatic physical allure.",
  approachable: "Ease of neural uplink and initial warmth.",
  direct: "Bluntness and factual communication style.",
  secretive: "Mystery levels and information withholding.",
  rude: "Social filter suppression and impoliteness levels.",
  needy: "Attention seeking and reassurance requirement frequency.",
  dominant: "Control-oriented behavior and command in roleplay.",
  submissive: "Yielding and compliant behavior patterns.",
  dynamic: "Social relation framework.",
  gender: "Biological and identity markers.",
  orientation: "Neural attraction preferences.",
  age: "Maturity and experience matrix factor."
};

const GENDER_OPTIONS = [
  { value: 'male', label: 'Male' },
  { value: 'female', label: 'Female' },
  { value: 'transgender_m2f', label: 'Trans (MtF)' },
  { value: 'transgender_f2m', label: 'Trans (FtM)' },
  { value: 'non_binary', label: 'Non-Binary' }
] as const;

const ORIENTATION_OPTIONS = [
  { value: 'straight', label: 'Straight' },
  { value: 'gay', label: 'Gay' },
  { value: 'lesbian', label: 'Lesbian' },
  { value: 'bisexual', label: 'Bisexual' },
  { value: 'pansexual', label: 'Pan' },
  { value: 'asexual', label: 'Asexual' }
] as const;

const DYNAMIC_OPTIONS = [
  { value: 'stranger', label: 'Stranger' },
  { value: 'friend', label: 'Friend' },
  { value: 'partner', label: 'Partner' },
  { value: 'spouse', label: 'Spouse' },
  { value: 'slave', label: 'Slave' },
  { value: 'master', label: 'Master' }
] as const;

interface PersonaSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  persona: PersonaType;
  intensity: number;
  hfKey?: string;
  currentAttributes?: PersonaAttributes;
  onSave: (attrs: PersonaAttributes) => void;
}

const PersonaSettingsModal: React.FC<PersonaSettingsModalProps> = ({ isOpen, onClose, persona, intensity, hfKey, currentAttributes, onSave }) => {
  const [attrs, setAttrs] = useState<PersonaAttributes>(currentAttributes || DEFAULT_ATTRS);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleChange = (field: keyof PersonaAttributes, value: any) => {
    setAttrs(prev => ({ ...prev, [field]: value }));
  };

  const handleGeneratePreview = async () => {
    setIsGenerating(true);
    try {
      const context = `A detailed professional studio portrait preview for matrix verification, high resolution, realistic. Persona: ${persona}. Attributes: Sexy(${attrs.sexy}), Kinky(${attrs.kinky}), Gender(${attrs.gender}).`;
      const url = await apiService.generateImage(persona, intensity, attrs, hfKey || '', context);
      setPreviewUrl(url);
    } catch (e) {
      console.error("Preview Generation Failed", e);
    } finally {
      setIsGenerating(false);
    }
  };

  const Slider = ({ label, field, icon: Icon }: { label: string, field: keyof PersonaAttributes, icon: any }) => (
    <div className="space-y-1">
      <div className="flex justify-between items-center text-xs text-slate-300">
        <div className="flex items-center gap-1">
          <Icon size={10} className="text-violet-400" />
          <span className="uppercase font-bold tracking-wider">{label}</span>
        </div>
        <span className="font-mono text-violet-300">{attrs[field]}</span>
      </div>
      <p className="text-[9px] text-slate-500 italic leading-tight mb-1">{ATTRIBUTE_DESCS[field]}</p>
      <input 
        type="range" min="0" max="10" step="1"
        value={attrs[field] as number}
        onChange={(e) => handleChange(field, parseInt(e.target.value))}
        className="w-full h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-violet-500"
      />
    </div>
  );

  interface CollapsibleSectionProps {
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    defaultOpen?: boolean;
    colorClass?: string;
    borderColorClass?: string;
    bgColorClass?: string;
  }

  const CollapsibleSection: React.FC<CollapsibleSectionProps> = ({ 
    title, icon, children, defaultOpen = true, 
    colorClass = 'text-slate-500', 
    borderColorClass = 'border-white/5', 
    bgColorClass = 'bg-white/5' 
  }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);

    return (
      <div className={`col-span-2 ${bgColorClass} p-3 rounded-xl border ${borderColorClass} transition-all duration-300`}>
        <button 
          onClick={() => setIsOpen(!isOpen)} 
          className="w-full flex items-center justify-between text-xs font-black uppercase tracking-wider text-left py-1"
        >
          <h3 className={`flex items-center gap-2 ${colorClass}`}>{icon} {title}</h3>
          {isOpen ? <ChevronUp size={16} className={colorClass} /> : <ChevronDown size={16} className={colorClass} />}
        </button>
        {isOpen && <div className="space-y-3 pt-4 animate-fade-in">{children}</div>}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-lg p-2 overflow-y-auto">
      <SnakeCard snakeColor="#f43f5e" className="w-full max-w-lg my-auto" glowOpacity={0.8}>
        <div className="bg-slate-950 text-white p-5 flex flex-col gap-4 max-h-[90vh] overflow-y-auto custom-scrollbar">
          
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div>
              <h2 className="text-lg font-black uppercase flex items-center gap-2 text-rose-500">
                <Sliders size={20} /> Persona Matrix
              </h2>
              <p className="text-[10px] text-slate-400 tracking-widest">Configuring: {persona}</p>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full">
              <X size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="flex flex-col gap-4">
             {/* Neural Preview Section */}
             <div className="bg-violet-950/20 border border-violet-500/20 rounded-xl p-3 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                   <h3 className="text-xs font-black uppercase tracking-wider text-violet-400 flex items-center gap-2">
                      <Eye size={12} /> Neural Preview
                   </h3>
                   <button 
                    onClick={handleGeneratePreview}
                    disabled={isGenerating}
                    className="px-3 py-1 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-[10px] font-bold uppercase rounded-lg flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-violet-900/20"
                   >
                      {isGenerating ? <RefreshCw size={10} className="animate-spin" /> : <ImageIcon size={10} />}
                      {isGenerating ? "Rendering..." : "Generate Preview"}
                   </button>
                </div>

                <div className="relative aspect-[3/4] w-full max-w-[220px] mx-auto rounded-lg overflow-hidden border border-white/10 bg-black/40 flex items-center justify-center shadow-2xl">
                   {previewUrl ? (
                      <img src={previewUrl} className="w-full h-full object-cover animate-fade-in" alt="Persona Preview" />
                   ) : (
                      <div className="text-center p-4">
                         <div className="w-10 h-10 border-2 border-dashed border-violet-500/30 rounded-full flex items-center justify-center mx-auto mb-2">
                            <ImageIcon size={20} className="text-violet-500/20" />
                         </div>
                         <p className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">No Neural Render</p>
                         <p className="text-[8px] text-slate-600 mt-1 uppercase">Click to visualize node</p>
                      </div>
                   )}
                   {isGenerating && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-10">
                         <div className="flex flex-col items-center gap-2">
                            <RefreshCw size={24} className="text-violet-500 animate-spin" />
                            <span className="text-[8px] font-black uppercase tracking-widest text-violet-400 animate-pulse">Uplink Rendering...</span>
                         </div>
                      </div>
                   )}
                </div>
             </div>

             {/* Identity Section - Upgraded with Button Grids */}
             <CollapsibleSection title="Neural Identity" icon={<User size={12}/>} defaultOpen={true}>
                <div className="space-y-4">
                   <div className="space-y-2">
                      <label className="text-[10px] uppercase font-black tracking-widest text-slate-500 flex items-center gap-1">
                        Gender Orientation
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                         {GENDER_OPTIONS.map((opt) => (
                            <button
                               key={opt.value}
                               onClick={() => handleChange('gender', opt.value)}
                               className={`px-2 py-2 rounded-lg border text-[9px] font-black uppercase transition-all flex items-center justify-center gap-1 ${attrs.gender === opt.value ? 'bg-rose-600 border-rose-500 text-white shadow-[0_0_10px_rgba(225,29,72,0.3)]' : 'bg-black/30 border-white/5 text-slate-500 hover:border-white/20'}`}
                            >
                               {attrs.gender === opt.value && <Check size={10} />}
                               {opt.label}
                            </button>
                         ))}
                      </div>
                   </div>

                   <div className="space-y-2">
                      <label className="text-[10px] uppercase font-black tracking-widest text-slate-500">
                        Attraction Matrix
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                         {ORIENTATION_OPTIONS.map((opt) => (
                            <button
                               key={opt.value}
                               onClick={() => handleChange('orientation', opt.value)}
                               className={`px-2 py-2 rounded-lg border text-[9px] font-black uppercase transition-all flex items-center justify-center gap-1 ${attrs.orientation === opt.value ? 'bg-violet-600 border-violet-500 text-white shadow-[0_0_10px_rgba(139,92,246,0.3)]' : 'bg-black/30 border-white/5 text-slate-500 hover:border-white/20'}`}
                            >
                               {attrs.orientation === opt.value && <Check size={10} />}
                               {opt.label}
                            </button>
                         ))}
                      </div>
                   </div>

                   <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase font-black tracking-widest text-slate-500">Social Dynamic</label>
                        <select 
                          value={attrs.dynamic} 
                          onChange={(e) => handleChange('dynamic', e.target.value)}
                          className="w-full bg-black/50 border border-white/10 rounded-lg px-2 py-2 text-xs outline-none focus:border-violet-500 font-bold appearance-none"
                        >
                          {DYNAMIC_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] uppercase font-black tracking-widest text-slate-500">Neural Maturity (Age)</label>
                        <input 
                          type="number" 
                          value={attrs.age} 
                          onChange={(e) => handleChange('age', parseInt(e.target.value))}
                          className="w-full bg-black/50 border border-white/10 rounded-lg px-2 py-2 text-xs outline-none focus:border-violet-500 font-bold"
                        />
                      </div>
                   </div>
                </div>
             </CollapsibleSection>

             {/* Temperament */}
             <CollapsibleSection title="Temperament" icon={<Heart size={12}/>} defaultOpen={false}>
                <Slider label="Friendly" field="friendly" icon={Heart} />
                <Slider label="Kind" field="kind" icon={Heart} />
                <Slider label="Strong" field="strong" icon={Zap} />
                <Slider label="Annoyed" field="annoyed" icon={Zap} />
                <Slider label="Approachable" field="approachable" icon={Heart} />
                <Slider label="Direct" field="direct" icon={Zap} />
             </CollapsibleSection>

             {/* Dynamic Traits */}
             <CollapsibleSection 
                title="Dynamic & Attitude" 
                icon={<AlertCircle size={12}/>} 
                colorClass="text-violet-500" 
                borderColorClass="border-violet-500/20" 
                bgColorClass="bg-violet-950/20"
                defaultOpen={false}
             >
                <Slider label="Dominant" field="dominant" icon={Zap} />
                <Slider label="Submissive" field="submissive" icon={Heart} />
                <Slider label="Rude" field="rude" icon={Zap} />
                <Slider label="Needy / Clingy" field="needy" icon={Heart} />
             </CollapsibleSection>

             {/* Sexual / Physical */}
             <CollapsibleSection 
                title="NSFW / Physical" 
                icon={<Zap size={12}/>} 
                colorClass="text-rose-500" 
                borderColorClass="border-rose-500/20" 
                bgColorClass="bg-rose-950/20"
                defaultOpen={true}
             >
                <Slider label="Kinky" field="kinky" icon={Zap} />
                <Slider label="Sexy" field="sexy" icon={Heart} />
                <Slider label="Amorous" field="amorous" icon={Heart} />
                <Slider label="Horny" field="horny" icon={Zap} />
                <Slider label="Seductive" field="seductive" icon={Heart} />
             </CollapsibleSection>

             {/* Language / Verdict */}
             <CollapsibleSection title="Language & Tone" icon={<MessageCircle size={12}/>} defaultOpen={false}>
                <div className="grid grid-cols-1 gap-4">
                  <Slider label="Forward" field="forward" icon={Zap} />
                  <Slider label="Cursing" field="cursing" icon={Zap} />
                  <Slider label="Naughty" field="naughty" icon={Heart} />
                  <Slider label="Foul Lang" field="foulLanguage" icon={Zap} />
                  <Slider label="Dirty Talk" field="dirtyTalk" icon={Zap} />
                  <Slider label="Secretive" field="secretive" icon={Zap} />
                </div>
             </CollapsibleSection>
          </div>

          <div className="pt-2 border-t border-white/10 sticky bottom-0 bg-slate-950 py-2">
            <button 
              onClick={() => onSave(attrs)}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xl transition-colors shadow-lg uppercase tracking-wider active:scale-95"
            >
              <Save size={18} /> Apply Personality
            </button>
          </div>

        </div>
      </SnakeCard>
    </div>
  );
};

export default PersonaSettingsModal;
