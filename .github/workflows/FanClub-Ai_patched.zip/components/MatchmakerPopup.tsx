
import React, { useState } from 'react';
import { NeuralTalent } from '../types';
import SnakeCard from './SnakeCard';
import { 
  Flame, ShieldCheck, MapPin, ExternalLink, MessageCircle, Play, 
  Heart, X, Video, Users, Check, AlertCircle, Phone, Smartphone, Lock, Star
} from 'lucide-react';

interface MatchmakerPopupProps {
  talent: NeuralTalent;
  onClose: () => void;
  onBook: (duration: number, type: 'simulation' | 'video' | 'interaction') => void;
}

const MatchmakerPopup: React.FC<MatchmakerPopupProps> = ({ talent, onClose, onBook }) => {
  const [selectedType, setSelectedType] = useState<'simulation' | 'video' | 'interaction' | null>(null);

  const OPTIONS = [
    { 
      id: 'simulation', 
      label: 'Digital Private Show', 
      icon: MessageCircle, 
      desc: 'Discreet WhatsApp chat & Video call simulation',
      price: 'R10 / min',
      color: 'blue'
    },
    { 
      id: 'video', 
      label: 'Live VIP Call', 
      icon: Video, 
      desc: 'Real-time Video Uplink with Performer',
      price: 'R30 / min',
      color: 'indigo'
    },
    { 
      id: 'interaction', 
      label: 'Physical VIP Booking', 
      icon: Heart, 
      desc: 'Exclusive Hotel interaction + Sexual services',
      price: 'R1500 / hr',
      color: 'rose'
    }
  ];

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in">
      <SnakeCard snakeColor="#f43f5e" className="w-full max-w-sm" innerClassName="bg-neutral-950 p-6 flex flex-col gap-5 border border-club-900/20">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-club-600/20 rounded-xl text-club-500 shadow-[0_0_15px_rgba(244,63,94,0.3)]"><Flame size={20} /></div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-tighter text-white">VIP Booking Node</h3>
              <p className="text-[9px] text-gold-500 font-black uppercase tracking-widest italic gold-text">FanClub-Ai™ Priority</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-white/5 rounded-full text-slate-500"><X size={18} /></button>
        </div>

        <div className="relative aspect-video rounded-2xl overflow-hidden group border border-white/5">
          <img src={`https://image.pollinations.ai/prompt/adult%20blonde%20woman%20seductive%20lingerie%208k%20extreme%20detail?seed=${talent.id}`} className="w-full h-full object-cover filter blur-3xl group-hover:blur-2xl transition-all duration-1000 scale-125" alt="Club Performer" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
          <div className="absolute inset-0 flex flex-col items-center justify-center">
             <Lock size={32} className="text-white/10 mb-2" />
             <p className="text-[8px] font-black uppercase text-white/30 tracking-widest">VIP Vetting Active</p>
          </div>
          <div className="absolute bottom-4 left-4">
            <h4 className="text-xl font-black uppercase italic tracking-tighter text-white neon-text">{talent.streetName}</h4>
            <div className="flex items-center gap-2 text-[9px] font-black text-club-500 uppercase tracking-tighter italic">
              <MapPin size={10} /> {talent.physical.height} | {talent.physical.hairColor} | ~2.4km
            </div>
          </div>
        </div>

        <div className="space-y-2">
           {OPTIONS.map(opt => (
             <button 
               key={opt.id}
               onClick={() => setSelectedType(opt.id as any)}
               className={`w-full p-4 rounded-2xl border transition-all text-left flex items-center justify-between ${selectedType === opt.id ? `bg-club-600/10 border-club-600 shadow-xl` : 'bg-white/5 border-white/5 hover:border-white/10'}`}
             >
                <div className="flex items-center gap-3">
                   <div className={`p-2 rounded-xl bg-${opt.color}-500/20 text-${opt.color}-500`}>
                      <opt.icon size={20} />
                   </div>
                   <div>
                      <p className="text-[11px] font-black uppercase tracking-tight text-white">{opt.label}</p>
                      <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">{opt.desc}</p>
                   </div>
                </div>
                <div className="text-right">
                   <p className="text-[10px] font-black uppercase text-gold-500 gold-text">{opt.price}</p>
                   {selectedType === opt.id && <Check size={12} className="text-club-500 ml-auto mt-1" />}
                </div>
             </button>
           ))}
        </div>

        {selectedType && (
          <div className="animate-fade-in space-y-4">
             <div className="bg-club-950/20 p-3 rounded-xl border border-club-500/20 flex gap-3 items-start">
                <ShieldCheck size={16} className="text-club-500 shrink-0" />
                <p className="text-[9px] text-club-200 font-bold uppercase leading-relaxed tracking-tighter italic">
                  Private Session confirmed via SA-iLabs Encryption. Secure iKhoka Payment includes mandatory R150 Bouncer/Uber Logistics Fee.
                </p>
             </div>
             <button 
               onClick={() => onBook(60, selectedType)} 
               className="w-full bg-club-600 py-4 rounded-2xl font-black uppercase text-xs shadow-2xl flex items-center justify-center gap-2 active:scale-95 transition-all text-white"
             >
               Engage VIP Interaction
             </button>
          </div>
        )}

        <div className="flex justify-center items-center gap-1.5 opacity-30">
           <Star size={10} className="text-gold-500" />
           <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest italic">💃FanClub-Ai™ Platinum Guarantee</p>
        </div>
      </SnakeCard>
    </div>
  );
};

export default MatchmakerPopup;
