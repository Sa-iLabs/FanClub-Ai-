import React from 'react';

interface SnakeCardProps {
  children: React.ReactNode;
  snakeColor: string;
  className?: string;
  innerClassName?: string;
  glowOpacity?: number;
  padding?: string;
}

const SnakeCard: React.FC<SnakeCardProps> = ({ 
  children, 
  snakeColor, 
  className = '', 
  innerClassName = '',
  glowOpacity = 0.8, 
  padding = 'p-[4px]' 
}) => {
  return (
    <div className={`relative group overflow-hidden rounded-2xl ${padding} ${className} shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5)] transition-all duration-500`}>
      {/* Primary Snake Gradient - Fast Spin */}
      <div 
        className="absolute inset-[-200%] animate-spin-slow"
        style={{ 
          background: `conic-gradient(from 90deg at 50% 50%, transparent 0%, transparent 45%, ${snakeColor} 100%)`,
          opacity: glowOpacity
        }}
      />
      
      {/* Secondary Interference Pattern - Reverse Spin for Depth */}
       <div 
        className="absolute inset-[-200%] animate-[spin_5s_linear_infinite_reverse]"
        style={{ 
          background: `conic-gradient(from 270deg at 50% 50%, transparent 0%, transparent 60%, ${snakeColor} 100%)`,
          opacity: glowOpacity * 0.4,
          filter: 'blur(20px)'
        }}
      />
      
      {/* Glassy Overlay for "Platinum" Shine */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-black/20 opacity-50 pointer-events-none rounded-2xl z-10" />
      
      {/* Inner Content - The "Card" */}
      <div className={`relative h-full w-full rounded-[12px] z-20 overflow-hidden shadow-inner ${innerClassName}`}>
        {children}
      </div>
    </div>
  );
};

export default SnakeCard;