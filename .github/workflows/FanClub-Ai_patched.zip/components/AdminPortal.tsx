
import React, { useState, useMemo } from 'react';
import { NeuralTalent, Booking, FinancialRecord } from '../types';
import SnakeCard from './SnakeCard';
import LocationRadar from './LocationRadar';
import { 
  Users, Lock, X, Ban, ArrowUpCircle, ArrowDownCircle, 
  LayoutDashboard, Wallet, Truck, UserCheck, Eye, EyeOff, 
  Flame, ChevronUp, ChevronDown, Calendar, DollarSign, ShieldCheck, Radar
} from 'lucide-react';

interface AdminPortalProps {
  onClose: () => void;
  talentPool: NeuralTalent[];
  setTalentPool: React.Dispatch<React.SetStateAction<NeuralTalent[]>>;
  bookings: Booking[];
  setBookings: React.Dispatch<React.SetStateAction<Booking[]>>;
  ledger: FinancialRecord[];
  setLedger: React.Dispatch<React.SetStateAction<FinancialRecord[]>>;
  userLocation: {lat: number, lng: number} | null;
}

const AdminPortal: React.FC<AdminPortalProps> = ({ onClose, talentPool, setTalentPool, ledger, userLocation }) => {
  const [isAuth, setIsAuth] = useState(false);
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [tab, setTab] = useState<'dashboard' | 'vetting' | 'vault' | 'radar'>('dashboard');
  const [showSensitive, setShowSensitive] = useState(false);
  const [ledgerFilter, setLedgerFilter] = useState<'all' | 'income' | 'payout' | 'expense'>('all');

  const stats = useMemo(() => {
    const revenue = ledger.filter(l => l.type === 'income').reduce((a, b) => a + b.amount, 0);
    const payouts = ledger.filter(l => l.type === 'payout').reduce((a, b) => a + b.amount, 0);
    return { revenue, payouts, net: revenue - payouts };
  }, [ledger]);

  const filteredLedger = useMemo(() => {
    return ledger.filter(l => ledgerFilter === 'all' || l.type === ledgerFilter)
                 .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [ledger, ledgerFilter]);

  if (!isAuth) {
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95 backdrop-blur-3xl p-4">
        <SnakeCard snakeColor="#f43f5e" className="w-full max-w-sm" innerClassName="bg-neutral-950 p-8 border border-club-900/30">
          <form onSubmit={(e) => { e.preventDefault(); if(user==='Boss'&&pass==='Admin@2026') setIsAuth(true); else alert("Invalid Sudo Node Credentials."); }} className="space-y-4">
            <div className="text-center mb-6">
              <Flame size={48} className="mx-auto text-club-500 mb-2 animate-pulse" />
              <h2 className="text-xl font-black uppercase text-club-500 tracking-tighter neon-text">Sudo Control Node</h2>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest italic">Management Authorization Required</p>
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase text-slate-600 ml-2 tracking-widest">Admin ID</label>
              <input type="text" value={user} onChange={e=>setUser(e.target.value)} className="w-full bg-neutral-900 border border-white/10 rounded-xl p-4 text-white text-sm font-bold outline-none focus:border-club-500" />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase text-slate-600 ml-2 tracking-widest">Passphrase</label>
              <input type="password" value={pass} onChange={e=>setPass(e.target.value)} className="w-full bg-neutral-900 border border-white/10 rounded-xl p-4 text-white text-sm font-bold outline-none focus:border-club-500" />
            </div>
            <button type="submit" className="w-full bg-club-600 py-4 rounded-xl font-black uppercase text-white shadow-lg shadow-club-900/40 hover:bg-club-500 transition-all">Engage Admin Uplink</button>
            <button type="button" onClick={onClose} className="w-full text-[10px] text-slate-500 uppercase font-black hover:text-white transition-colors">Abort Access</button>
          </form>
        </SnakeCard>
      </div>
    );
  }

  const handleApprove = (id: string) => {
    setTalentPool(prev => prev.map(t => t.id === id ? { ...t, status: 'active' } : t));
  };

  const handleReject = (id: string) => {
    setTalentPool(prev => prev.map(t => t.id === id ? { ...t, status: 'suspended' } : t));
  };

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-slate-950 text-slate-100 animate-fade-in overflow-hidden">
      <header className="bg-neutral-900 p-4 flex justify-between items-center border-b border-white/10">
        <div className="flex items-center gap-4">
           <div className="flex flex-col">
             <h1 className="text-lg font-black uppercase tracking-tighter neon-text">💃FanClub Management</h1>
             <p className="text-[8px] text-club-500 font-bold uppercase tracking-widest italic">Official iKhokha Merchant Portal</p>
           </div>
           <nav className="flex gap-1 ml-4 overflow-x-auto scrollbar-hide">
             {['dashboard', 'vetting', 'vault', 'radar'].map(t => (
               <button key={t} onClick={() => setTab(t as any)} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all whitespace-nowrap ${tab === t ? 'bg-club-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}>{t}</button>
             ))}
           </nav>
        </div>
        <div className="flex items-center gap-3">
           <button onClick={() => setShowSensitive(!showSensitive)} className={`p-2 rounded-lg transition-all ${showSensitive ? 'bg-rose-600/20 text-rose-500' : 'text-slate-500'}`} title="Toggle Sensitive Data">
             <Eye size={18} />
           </button>
           <button onClick={onClose} className="p-2 text-slate-500 hover:text-white transition-colors"><X size={20} /></button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-6 bg-black custom-scrollbar">
        {tab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-neutral-900 p-6 rounded-3xl border border-white/5 relative overflow-hidden group">
                <div className="absolute top-2 right-2 w-4 h-4 bg-gold-600 rounded-sm flex items-center justify-center text-[8px] text-black font-black italic">iK</div>
                <p className="text-[10px] font-black uppercase text-slate-500 mb-1 italic">Gross Settlement (iKhokha)</p>
                <h3 className="text-3xl font-black text-white italic">R {stats.revenue.toLocaleString()}</h3>
                <p className="text-[8px] text-green-500 font-bold mt-2 uppercase tracking-tighter">Verified Node Volume</p>
              </div>
              <div className="bg-neutral-900 p-6 rounded-3xl border border-white/5">
                <p className="text-[10px] font-black uppercase text-slate-500 mb-1 italic">Active Payouts (60%)</p>
                <h3 className="text-3xl font-black text-rose-500 italic">R {stats.payouts.toLocaleString()}</h3>
                <p className="text-[8px] text-slate-500 font-bold mt-2 uppercase tracking-tighter">Due to Performers</p>
              </div>
              <div className="bg-club-950/20 p-6 rounded-3xl border border-club-500/20 shadow-xl shadow-club-900/10">
                <p className="text-[10px] font-black uppercase text-club-500 mb-1 italic">Club Margin (40%)</p>
                <h3 className="text-3xl font-black text-white italic">R {stats.net.toLocaleString()}</h3>
                <p className="text-[8px] text-club-500 font-bold mt-2 uppercase tracking-tighter">Platform Retention</p>
              </div>
            </div>
            
            <div className="bg-neutral-900 p-6 rounded-3xl border border-white/5">
               <h4 className="text-[10px] font-black uppercase text-slate-500 mb-4 tracking-widest italic">Club Statistics</h4>
               <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                     <p className="text-xl font-black text-white">{talentPool.length}</p>
                     <p className="text-[8px] font-black uppercase text-slate-600">Total Talent</p>
                  </div>
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                     <p className="text-xl font-black text-green-500">{talentPool.filter(t=>t.status==='active').length}</p>
                     <p className="text-[8px] font-black uppercase text-slate-600">Active</p>
                  </div>
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                     <p className="text-xl font-black text-amber-500">{talentPool.filter(t=>t.status==='pending').length}</p>
                     <p className="text-[8px] font-black uppercase text-slate-600">Pending</p>
                  </div>
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                     <p className="text-xl font-black text-rose-500">{talentPool.filter(t=>t.status==='suspended').length}</p>
                     <p className="text-[8px] font-black uppercase text-slate-600">Banned</p>
                  </div>
               </div>
            </div>
          </div>
        )}

        {tab === 'vetting' && (
          <div className="space-y-4">
            <h2 className="text-xl font-black uppercase italic tracking-tighter text-white">Vetting Node: Performer Approval</h2>
            <div className="bg-neutral-900 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-800 font-black uppercase text-slate-500">
                  <tr>
                    <th className="p-6">Stage Name</th>
                    {showSensitive && <th className="p-6">Compliance Data</th>}
                    <th className="p-6">Status</th>
                    <th className="p-6 text-right">Verification</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-bold italic">
                  {talentPool.map(t => (
                    <tr key={t.id} className="hover:bg-white/5 transition-colors">
                      <td className="p-6 font-black uppercase text-white">{t.streetName}</td>
                      {showSensitive && (
                        <td className="p-6 text-slate-500">
                           <p className="uppercase text-slate-300 mb-1">{t.trueName}</p>
                           <p className="text-[9px] mb-1">ID: {t.idNumber}</p>
                           <p className="text-[9px] italic text-slate-400">{t.bankAccount.bank} | {t.bankAccount.accountNumber}</p>
                        </td>
                      )}
                      <td className="p-6">
                         <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase border ${t.status === 'active' ? 'bg-green-600/10 text-green-500 border-green-500/20' : t.status === 'pending' ? 'bg-amber-600/10 text-amber-500 border-amber-500/20' : 'bg-rose-600/10 text-rose-500 border-rose-500/20'}`}>{t.status}</span>
                      </td>
                      <td className="p-6 text-right space-x-2">
                        {t.status !== 'active' && (
                          <button onClick={() => handleApprove(t.id)} className="p-2.5 bg-green-600/10 text-green-500 rounded-xl hover:bg-green-600/20 transition-all shadow-lg" title="Approve Performer"><UserCheck size={18} /></button>
                        )}
                        {t.status !== 'suspended' && (
                          <button onClick={() => handleReject(t.id)} className="p-2.5 bg-rose-600/10 text-rose-500 rounded-xl hover:bg-rose-600/20 transition-all shadow-lg" title="Suspend Performer"><Ban size={18} /></button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'vault' && (
          <div className="space-y-4">
             <div className="flex justify-between items-center">
                <h2 className="text-xl font-black uppercase italic tracking-tighter text-white">Vault Ledger Node</h2>
                <div className="flex bg-neutral-900 rounded-full p-1 border border-white/10 shadow-lg">
                  {['all', 'income', 'payout', 'expense'].map(f => (
                    <button key={f} onClick={() => setLedgerFilter(f as any)} className={`px-5 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${ledgerFilter === f ? 'bg-club-600 text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{f}</button>
                  ))}
                </div>
             </div>
             <div className="bg-neutral-900 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
               <table className="w-full text-left text-[10px] font-bold">
                 <thead className="bg-neutral-800 font-black uppercase text-slate-500">
                    <tr>
                      <th className="p-6">Timestamp</th>
                      <th className="p-6">Type</th>
                      <th className="p-6">Description</th>
                      <th className="p-6 text-right">Amount (ZAR)</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-white/5 uppercase tracking-tight">
                    {filteredLedger.map(l => (
                      <tr key={l.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-6 text-slate-500 font-mono italic">{new Date(l.date).toLocaleString()}</td>
                        <td className="p-6">
                           <div className="flex items-center gap-2">
                             {l.type === 'income' ? <ArrowUpCircle size={14} className="text-green-500"/> : <ArrowDownCircle size={14} className="text-rose-500"/>}
                             <span className={`italic ${l.type === 'income' ? 'text-green-500' : 'text-rose-500'}`}>{l.type}</span>
                           </div>
                        </td>
                        <td className="p-6 text-slate-300 italic opacity-80">{l.description}</td>
                        <td className={`p-6 text-right font-black italic text-sm ${l.type === 'income' ? 'text-white' : 'text-slate-500'}`}>R {l.amount.toLocaleString()}</td>
                      </tr>
                    ))}
                 </tbody>
               </table>
             </div>
          </div>
        )}

        {tab === 'radar' && (
          <div className="space-y-4 h-full flex flex-col">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-black uppercase italic tracking-tighter text-white">Matrix Fleet Radar</h2>
              <div className="px-3 py-1 bg-club-600 text-[10px] font-black uppercase rounded-full animate-pulse flex items-center gap-2">
                <Radar size={12} /> Live Uplink
              </div>
            </div>
            <div className="flex-1 bg-neutral-900 rounded-3xl border border-white/10 overflow-hidden relative">
              <LocationRadar 
                performers={talentPool.filter(t => t.status === 'active')} 
                userLocation={userLocation} 
              />
            </div>
          </div>
        )}
      </main>

      <footer className="bg-neutral-900 p-4 border-t border-white/10 flex justify-center items-center gap-4">
        <p className="text-[8px] font-black uppercase tracking-[0.3em] text-slate-600 italic">Payments Verified via iKhokha Gateway Terminal</p>
        <div className="flex items-center gap-1.5">
          <div className="w-4 h-4 bg-[#fbbf24] rounded-sm flex items-center justify-center text-[10px] text-black font-black italic">iK</div>
          <span className="text-[10px] font-black text-white italic">iKhokha Terminal</span>
        </div>
      </footer>
    </div>
  );
};

export default AdminPortal;
