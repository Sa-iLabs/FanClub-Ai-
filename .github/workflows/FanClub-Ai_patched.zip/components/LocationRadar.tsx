
import React, { useMemo } from 'react';
import { NeuralTalent } from '../types';
import { MapPin, User, Radar, Flame } from 'lucide-react';

interface LocationRadarProps {
  performers: NeuralTalent[];
  userLocation: {lat: number, lng: number} | null;
}

const LocationRadar: React.FC<LocationRadarProps> = ({ performers, userLocation }) => {
  // Simple coordinate normalization for a stylized map
  // Bounds for visual grid (e.g., covering parts of SA or local area)
  const bounds = useMemo(() => {
    if (!userLocation) return { minLat: -35, maxLat: -22, minLng: 15, maxLng: 33 };
    return {
      minLat: userLocation.lat - 0.1,
      maxLat: userLocation.lat + 0.1,
      minLng: userLocation.lng - 0.1,
      maxLng: userLocation.lng + 0.1
    };
  }, [userLocation]);

  const normalize = (lat: number, lng: number) => {
    const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
    const y = 100 - ((lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100;
    return { x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) };
  };

  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden">
      {/* Grid Lines */}
      <div className="absolute inset-0 opacity-10" style={{ 
        backgroundImage: 'linear-gradient(#4c1d95 1px, transparent 1px), linear-gradient(90deg, #4c1d95 1px, transparent 1px)',
        backgroundSize: '40px 40px'
      }} />
      
      {/* Radar Rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-1/4 aspect-square border border-indigo-500/20 rounded-full animate-pulse-slow" />
        <div className="w-1/2 aspect-square border border-indigo-500/10 rounded-full animate-pulse-slow" style={{ animationDelay: '1s' }} />
        <div className="w-3/4 aspect-square border border-indigo-500/5 rounded-full animate-pulse-slow" style={{ animationDelay: '2s' }} />
      </div>

      {/* User Pin */}
      {userLocation && (
        <div 
          className="absolute z-10 transition-all duration-1000"
          style={{ 
            left: `${normalize(userLocation.lat, userLocation.lng).x}%`, 
            top: `${normalize(userLocation.lat, userLocation.lng).y}%`,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <div className="relative">
            <div className="absolute inset-0 w-8 h-8 bg-blue-500/20 rounded-full animate-ping" />
            <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-[0_0_15px_rgba(59,130,246,0.8)] flex items-center justify-center">
               <User size={8} className="text-white" />
            </div>
            <span className="absolute top-6 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase text-blue-400 bg-black/80 px-1.5 py-0.5 rounded whitespace-nowrap border border-blue-500/20">Client Node (You)</span>
          </div>
        </div>
      )}

      {/* Performer Pins */}
      {performers.map(p => {
        if (!p.currentLocation) return null;
        const pos = normalize(p.currentLocation.lat, p.currentLocation.lng);
        return (
          <div 
            key={p.id}
            className="absolute z-20 transition-all duration-1000 group cursor-pointer"
            style={{ 
              left: `${pos.x}%`, 
              top: `${pos.y}%`,
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div className="relative">
              <div className="absolute inset-0 w-10 h-10 bg-rose-500/20 rounded-full animate-pulse" />
              <div className="w-5 h-5 bg-rose-600 rounded-full border-2 border-white shadow-[0_0_15px_rgba(244,63,94,0.8)] flex items-center justify-center transition-transform group-hover:scale-125">
                 <Flame size={10} className="text-white" />
              </div>
              <div className="absolute top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 p-2 rounded-xl border border-rose-500/30 shadow-2xl z-30 pointer-events-none">
                 <p className="text-[9px] font-black text-white uppercase italic">{p.streetName}</p>
                 <p className="text-[7px] font-bold text-rose-400 uppercase tracking-tighter">Status: {p.status}</p>
              </div>
              <span className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[7px] font-black uppercase text-rose-400 bg-black/80 px-1.5 py-0.5 rounded whitespace-nowrap border border-rose-500/20">{p.streetName}</span>
            </div>
          </div>
        );
      })}

      <div className="absolute bottom-4 right-4 bg-black/80 border border-white/10 p-2 rounded-xl backdrop-blur-md">
         <p className="text-[7px] font-black uppercase tracking-widest text-slate-500 italic">Matrix Coordinate System v2.1</p>
         <p className="text-[6px] text-slate-600 uppercase mt-0.5">Discreet Node Visualization Active</p>
      </div>
    </div>
  );
};

export default LocationRadar;
