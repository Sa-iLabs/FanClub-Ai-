
import React, { useState, useEffect } from 'react';
import SnakeCard from './SnakeCard';
import { X, Save, ToggleRight, ToggleLeft, Volume2, CheckCircle2, ImageIcon, RefreshCw, Maximize, Layout, AudioLines } from 'lucide-react';
import { UserSettings, ImageSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  enableAutoVoice: boolean;
  enableAutoImage: boolean;
  enableSFX: boolean;
  imageSettings: ImageSettings;
  preferredVoice: string;
  voiceProvider: UserSettings['voiceProvider'];
  voiceId?: string;
  onSaveKeys: (autoVoice: boolean, autoImage: boolean, enableSFX: boolean, preferredVoice: string, voiceProvider: any, voiceId: string | undefined, imageSettings: ImageSettings) => void;
}

const ASPECT_RATIOS: { label: string, value: ImageSettings['aspectRatio'], w: number, h: number }[] = [
  { label: 'Square', value: '1:1', w: 1024, h: 1024 },
  { label: 'Cinema', value: '16:9', w: 1280, h: 720 },
  { label: 'Portrait', value: '9:16', w: 720, h: 1280 },
];

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, onClose, enableAutoVoice, enableAutoImage, enableSFX, imageSettings, preferredVoice, voiceProvider, voiceId, onSaveKeys 
}) => {
  const [vProvider, setVProvider] = useState(voiceProvider || 'native');
  const [vId, setVId] = useState(voiceId || '');
  const [autoVoice, setAutoVoice] = useState(enableAutoVoice);
  const [autoImage, setAutoImage] = useState(enableAutoImage);
  const [sfx, setSfx] = useState(enableSFX);
  const [imgSettings, setImgSettings] = useState<ImageSettings>(imageSettings || { width: 1024, height: 1024, aspectRatio: '1:1' });
  const [activeTab, setActiveTab] = useState<'vision' | 'voice' | 'data'>('vision');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  useEffect(() => {
    if (isOpen) {
      setVProvider(voiceProvider || 'native');
      setVId(voiceId || '');
      setAutoVoice(enableAutoVoice);
      setAutoImage(enableAutoImage);
      setSfx(enableSFX);
      setImgSettings(imageSettings);
      setSaveStatus('idle');
    }
  }, [isOpen, enableAutoVoice, enableAutoImage, enableSFX, voiceProvider, voiceId, imageSettings]);

  if (!isOpen) return null;

  const handleSave = () => {
    setSaveStatus('saving');
    setTimeout(() => {
      onSaveKeys(autoVoice, autoImage, sfx, preferredVoice, vProvider, vId, imgSettings);
      setSaveStatus('saved');
      setTimeout(onClose, 600);
    }, 400);
  };

  const ToggleItem = ({ label, icon: Icon, color, isActive, onClick, subText }: any) => (
    <div className={`flex items-center justify-between p-3 rounded-xl border transition-all ${isActive ? `bg-${color}-500/10 border-${color}-500/50` : 'bg-white/5 border-white/5'}`}>
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${isActive ? `bg-${color}-500/20 text-${color}-400` : 'bg-slate-800 text-slate-400'}`}>
          <Icon size={18} />
        </div>
        <div>
          <span className="text-xs font-bold uppercase tracking-wider block">{label}</span>
          <span className="text-[9px] text-slate-500">{subText}</span>
        </div>
      </div>
      <button onClick={onClick} className={isActive ? `text-${color}-400` : 'text-slate-600'}>
        {isActive ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <SnakeCard snakeColor="#8b5cf6" className="w-full max-w-md" glowOpacity={0.5}>
        <div className="bg-slate-900 text-white p-6 flex flex-col gap-5 max-h-[90vh] overflow-y-auto custom-scrollbar">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <h2 className="text-xl font-bold uppercase tracking-tighter">🌐 Node Control</h2>
            <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
          </div>

          <div className="flex p-1 bg-black/40 rounded-xl shadow-inner">
             <button onClick={() => setActiveTab('vision')} className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeTab === 'vision' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500'}`}>Vision</button>
             <button onClick={() => setActiveTab('voice')} className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeTab === 'voice' ? 'bg-rose-600 text-white shadow-md' : 'text-slate-500'}`}>Vocal</button>
             <button onClick={() => setActiveTab('data')} className={`flex-1 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeTab === 'data' ? 'bg-slate-700 text-white shadow-md' : 'text-slate-500'}`}>Data</button>
          </div>

          {activeTab === 'vision' && (
            <div className="space-y-4 animate-fade-in">
              <ToggleItem label="Auto-Visuals" icon={ImageIcon} color="indigo" isActive={autoImage} onClick={() => setAutoImage(!autoImage)} subText="Gemini Neural Vision Node" />
              <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-4">
                 <h3 className="text-[10px] font-black uppercase tracking-widest text-indigo-400 flex items-center gap-2">
                    <Layout size={12} /> Aspect Ratio Presets
                 </h3>
                 <div className="grid grid-cols-3 gap-2">
                    {ASPECT_RATIOS.map(ratio => (
                       <button 
                         key={ratio.value} 
                         onClick={() => setImgSettings({...imgSettings, aspectRatio: ratio.value})}
                         className={`px-2 py-2 rounded-lg border text-[9px] font-bold uppercase transition-all ${imgSettings.aspectRatio === ratio.value ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-white/5 border-white/5 text-slate-500'}`}
                       >
                          {ratio.label}
                       </button>
                    ))}
                 </div>
              </div>
            </div>
          )}

          {activeTab === 'voice' && (
             <div className="space-y-4 animate-fade-in">
                <ToggleItem label="Vocal Synthesis" icon={Volume2} color="rose" isActive={autoVoice} onClick={() => setAutoVoice(!autoVoice)} subText="Gemini Multi-Speaker TTS" />
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-slate-500 ml-1">Voice Node Provider</label>
                  <select 
                    value={vProvider} 
                    onChange={(e) => setVProvider(e.target.value as any)}
                    className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs focus:border-rose-500 outline-none"
                  >
                     <option value="gemini">Gemini Neural Vocal</option>
                     <option value="native">System Native</option>
                  </select>
                </div>
             </div>
          )}

          {activeTab === 'data' && (
            <div className="p-4 bg-slate-800/40 rounded-xl border border-white/5">
               <p className="text-[10px] text-slate-500 uppercase font-black leading-relaxed">
                 API Key strictly managed via process.env.API_KEY environment variable for absolute platform security.
               </p>
            </div>
          )}

          <div className="pt-4 border-t border-white/10 mt-auto">
            <button 
              onClick={handleSave}
              disabled={saveStatus !== 'idle'}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-black uppercase tracking-widest transition-all ${saveStatus === 'saved' ? 'bg-green-600 text-white' : 'bg-violet-600 hover:bg-violet-500 text-white shadow-lg'}`}
            >
              {saveStatus === 'saving' ? <RefreshCw size={18} className="animate-spin" /> : saveStatus === 'saved' ? <CheckCircle2 size={18} /> : <Save size={18} />}
              {saveStatus === 'saving' ? 'Uplinking...' : saveStatus === 'saved' ? 'Node Synced' : 'Sync Matrix'}
            </button>
          </div>
        </div>
      </SnakeCard>
    </div>
  );
};

export default SettingsModal;
