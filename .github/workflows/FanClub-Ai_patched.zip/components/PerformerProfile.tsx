
import React, { useState } from 'react';
import { NeuralTalent } from '../types';
import SnakeCard from './SnakeCard';
import { apiService } from '../services/api';
import { MapPin, Star, Flame, X, ShieldCheck, Heart, Lock, Calendar, MessageSquare, Video, Phone, ImageIcon, RefreshCw, Key, AlertTriangle, User } from 'lucide-react';

interface PerformerProfileProps {
  talent: NeuralTalent;
  onClose: () => void;
  onBook: (duration: number, type: 'simulation' | 'video' | 'interaction') => void;
  hasKey: boolean;
  onOpenKey: () => void;
}

const PerformerProfile: React.FC<PerformerProfileProps> = ({ talent, onClose, onBook, hasKey, onOpenKey }) => {
  const [explicitImages, setExplicitImages] = useState<Record<string, string>>({});
  const [loadingCategory, setLoadingCategory] = useState<string | null>(null);

  const handleGenerateExplicit = async (category: 'portrait' | 'lingerie' | 'nude' | 'explicit') => {
    if (!hasKey) {
      onOpenKey();
      return;
    }
    setLoadingCategory(category);
    const url = await apiService.generateExplicitImage(talent, category);
    if (url) {
      setExplicitImages(prev => ({ ...prev, [category]: url }));
    }
    setLoadingCategory(null);
  };

  return (
    <div className="fixed inset-0 z-[110] flex flex-col bg-black animate-fade-in overflow-hidden">
      <div className="relative h-[40vh] shrink-0">
        <img 
          src={explicitImages['portrait'] || `https://image.pollinations.ai/prompt/adult%20blonde%20woman%20seductive%20lingerie%208k%20extreme%20detail?seed=${talent.id}`} 
          className="w-full h-full object-cover filter brightness-75 transition-all duration-1000" 
          alt={talent.streetName} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/20" />
        <button onClick={onClose} className="absolute top-6 right-6 p-3 bg-black/40 backdrop-blur-xl rounded-full text-white border border-white/10">
          <X size={24} />
        </button>
        <div className="absolute bottom-6 left-6 right-6">
          <div className="flex items-end justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-club-600 px-2 py-0.5 rounded text-[10px] font-black uppercase text-white shadow-lg">Verified Performer</span>
                <span className="bg-gold-600 px-2 py-0.5 rounded text-[10px] font-black uppercase text-black shadow-lg flex items-center gap-1">
                  <Star size={10} fill="currentColor" /> {talent.rating}
                </span>
              </div>
              <h1 className="text-4xl font-black uppercase italic tracking-tighter text-white neon-text">{talent.streetName}</h1>
              <p className="text-xs font-bold text-slate-300 flex items-center gap-1 uppercase tracking-widest mt-1 opacity-80">
                <MapPin size={12} className="text-club-500" /> Matrix Node ~2.4km Nearby
              </p>
            </div>
            <div className="flex gap-2">
               <button className="p-3 bg-rose-600/20 backdrop-blur-xl rounded-2xl text-rose-500 border border-rose-500/30">
                 <Heart size={20} />
               </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 bg-neutral-950 rounded-t-[40px] -mt-10 relative z-10 p-6 overflow-y-auto custom-scrollbar">
        <div className="grid grid-cols-2 gap-4 mb-8">
           <div className="bg-white/5 p-4 rounded-3xl border border-white/5">
              <p className="text-[10px] font-black uppercase text-slate-500 mb-1">Physical Node</p>
              <div className="space-y-1 text-xs font-bold">
                 <p className="text-slate-300">Height: <span className="text-white">{talent.physical.height}</span></p>
                 <p className="text-slate-300">Weight: <span className="text-white">{talent.physical.weight}</span></p>
                 <p className="text-slate-300">Breast: <span className="text-white">{talent.physical.breastSize}</span></p>
              </div>
           </div>
           <div className="bg-white/5 p-4 rounded-3xl border border-white/5">
              <p className="text-[10px] font-black uppercase text-slate-500 mb-1">Specialties</p>
              <div className="flex flex-wrap gap-1">
                 <span className="bg-club-950/40 text-club-400 px-2 py-1 rounded-lg text-[9px] font-bold uppercase border border-club-900/30">Full Nude</span>
                 <span className="bg-club-950/40 text-club-400 px-2 py-1 rounded-lg text-[9px] font-bold uppercase border border-club-900/30">Explicit Action</span>
                 <span className="bg-club-950/40 text-club-400 px-2 py-1 rounded-lg text-[9px] font-bold uppercase border border-club-900/30">Hardcore</span>
              </div>
           </div>
        </div>

        <div className="space-y-6 mb-12">
           <h3 className="text-xs font-black uppercase tracking-widest text-gold-500 flex items-center gap-2 italic gold-text">
             <Flame size={14} className="text-club-500" /> Explicit Media Vault
           </h3>
           
           <div className="grid grid-cols-2 gap-4">
              {[
                { id: 'portrait', label: 'VIP Face Reveal', icon: User },
                { id: 'lingerie', label: 'Erotic Lingerie', icon: Heart },
                { id: 'nude', label: 'Full Nude Reveal', icon: Flame },
                { id: 'explicit', label: 'Explicit Detail', icon: AlertTriangle }
              ].map(cat => (
                <div key={cat.id} className="relative aspect-square rounded-3xl overflow-hidden border border-white/5 bg-neutral-900 group">
                   {explicitImages[cat.id] ? (
                     <img src={explicitImages[cat.id]} className="w-full h-full object-cover animate-fade-in group-hover:scale-110 transition-transform duration-500" />
                   ) : (
                     <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
                        <cat.icon size={24} className="text-white/10 mb-2" />
                        <p className="text-[9px] font-black uppercase text-slate-500 mb-3">{cat.label}</p>
                        <button 
                          onClick={() => handleGenerateExplicit(cat.id as any)}
                          disabled={loadingCategory === cat.id}
                          className="px-3 py-1.5 bg-club-600/20 text-club-500 rounded-full border border-club-500/30 text-[8px] font-black uppercase tracking-widest hover:bg-club-500 hover:text-white transition-all active:scale-95 flex items-center gap-1.5"
                        >
                           {loadingCategory === cat.id ? <RefreshCw size={10} className="animate-spin" /> : <Lock size={10} />}
                           {loadingCategory === cat.id ? 'Uplinking...' : 'Unlock Node'}
                        </button>
                     </div>
                   )}
                   {explicitImages[cat.id] && (
                     <div className="absolute bottom-0 inset-x-0 bg-black/60 backdrop-blur-md p-2 flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-[7px] font-black uppercase text-white tracking-widest">{cat.label}</span>
                        <RefreshCw size={10} className="text-white/50 cursor-pointer" onClick={() => handleGenerateExplicit(cat.id as any)} />
                     </div>
                   )}
                </div>
              ))}
           </div>

           {!hasKey && (
             <div className="bg-amber-950/20 border border-amber-500/20 p-4 rounded-3xl flex items-center gap-4">
                <Key size={24} className="text-amber-500 shrink-0" />
                <div className="flex-1">
                  <p className="text-[10px] font-black uppercase text-amber-200 tracking-tighter italic">High-Fidelity Neural Key Required</p>
                  <p className="text-[8px] text-amber-500/70 font-bold uppercase mt-0.5">Select a paid API key from your workspace to generate ultra-realistic explicit media.</p>
                </div>
                <button onClick={onOpenKey} className="bg-amber-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-black">Select Key</button>
             </div>
           )}
        </div>

        <div className="space-y-4 mb-32">
           <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
             <Calendar size={14} className="text-club-500" /> Book VIP Interaction
           </h3>
           
           <button onClick={() => onBook(30, 'simulation')} className="w-full flex items-center justify-between p-5 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-3xl group transition-all">
              <div className="flex items-center gap-4">
                 <div className="p-3 bg-blue-500/10 text-blue-400 rounded-2xl group-hover:scale-110 transition-transform"><MessageSquare size={20} /></div>
                 <div>
                    <p className="text-sm font-black uppercase text-white tracking-tight">Digital Private Show</p>
                    <p className="text-[10px] text-slate-500 font-bold">Discreet Chat & Simulated Video</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-xs font-black text-gold-500">R10 / Min</p>
                 <p className="text-[8px] text-slate-600 uppercase font-black">Instant Uplink</p>
              </div>
           </button>

           <button onClick={() => onBook(30, 'video')} className="w-full flex items-center justify-between p-5 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-3xl group transition-all">
              <div className="flex items-center gap-4">
                 <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-2xl group-hover:scale-110 transition-transform"><Video size={20} /></div>
                 <div>
                    <p className="text-sm font-black uppercase text-white tracking-tight">Live VIP Call</p>
                    <p className="text-[10px] text-slate-500 font-bold">Real-time Encrypted Video</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-xs font-black text-gold-500">R30 / Min</p>
                 <p className="text-[8px] text-slate-600 uppercase font-black">Verified Only</p>
              </div>
           </button>

           <button onClick={() => onBook(60, 'interaction')} className="w-full flex items-center justify-between p-5 bg-club-600 hover:bg-club-500 rounded-3xl group transition-all shadow-xl shadow-club-900/20">
              <div className="flex items-center gap-4">
                 <div className="p-3 bg-white/20 text-white rounded-2xl group-hover:scale-110 transition-transform"><Heart size={20} /></div>
                 <div className="text-left">
                    <p className="text-sm font-black uppercase text-white tracking-tight">Physical Interaction</p>
                    <p className="text-[10px] text-white/60 font-bold">Full VIP Suite Experience</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-xs font-black text-white">R1500 / Hr</p>
                 <p className="text-[8px] text-white/40 uppercase font-black">Escort Service</p>
              </div>
           </button>
        </div>
      </div>

      <div className="absolute bottom-8 left-6 right-6 pointer-events-none">
         <div className="bg-gold-600/10 backdrop-blur-xl border border-gold-500/30 p-4 rounded-3xl flex items-center gap-4 shadow-2xl">
            <ShieldCheck className="text-gold-500 shrink-0" size={20} />
            <p className="text-[9px] font-black uppercase text-gold-200 tracking-tighter leading-relaxed">
               All FanClub-Ai™ performers are verified adults. Generated imagery utilizes Gemini 3 Neural Matrix for ultra-realism. 100% NSFW.
            </p>
         </div>
      </div>
    </div>
  );
};

export default PerformerProfile;
