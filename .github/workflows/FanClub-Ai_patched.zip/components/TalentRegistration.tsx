
import React, { useState } from 'react';
import { NeuralTalent } from '../types';
import SnakeCard from './SnakeCard';
import { 
  Camera, Image as ImageIcon, CreditCard, User, Heart, Briefcase, 
  ChevronRight, ChevronLeft, ShieldCheck, Flame, Trash2, ShieldAlert,
  AlertTriangle, CheckSquare, XCircle, Activity, Sparkles, Star
} from 'lucide-react';

interface TalentRegistrationProps {
  onClose: () => void;
  onRegister: (talent: NeuralTalent) => void;
}

const TalentRegistration: React.FC<TalentRegistrationProps> = ({ onClose, onRegister }) => {
  const [step, setStep] = useState(1);
  const [data, setData] = useState<Partial<NeuralTalent>>({
    id: Math.random().toString(36).substr(2, 9),
    status: 'pending',
    rating: 5,
    physical: { weight: '', height: '', hairColor: '', eyeColor: '', breastSize: '' },
    bankAccount: { bank: '', branchCode: '', accountNumber: '', accountType: 'Savings' },
    preferences: { 
      fantasies: '', 
      abilities: '', 
      likes: '', 
      dislikes: '', 
      noGoZones: '', 
      noGoActions: '' 
    },
    portfolio: { clothed: [], underwear: [], fullFrontal: [], explicit: [], chosenErotic: [] }
  });

  const next = () => setStep(s => s + 1);
  const prev = () => setStep(s => s - 1);

  const handleSubmit = () => {
    onRegister(data as NeuralTalent);
  };

  return (
    <div className="fixed inset-0 z-[110] flex flex-col bg-black animate-fade-in overflow-hidden p-2 sm:p-4">
      <SnakeCard snakeColor="#f43f5e" className="flex-1" innerClassName="bg-neutral-950 p-6 flex flex-col border border-club-900/30">
        <header className="flex justify-between items-center mb-6 shrink-0">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-club-600/20 rounded-xl flex items-center justify-center text-club-500 shadow-lg"><Flame size={20} /></div>
             <div>
               <h1 className="text-xl font-black uppercase tracking-tighter text-club-500 neon-text">Performer Entry</h1>
               <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest italic">💃FanClub-Ai™ Talent Onboarding</p>
             </div>
          </div>
          <button onClick={onClose} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors text-slate-500"><XCircle size={20} /></button>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar space-y-8 pb-20">
          
          <div className="flex gap-1.5 px-1">
             {[1,2,3,4,5].map(i => (
               <div key={i} className={`flex-1 h-1 rounded-full transition-all duration-500 ${step >= i ? 'bg-club-600 shadow-[0_0_10px_rgba(244,63,94,0.5)]' : 'bg-white/5'}`} />
             ))}
          </div>

          {step === 1 && (
            <div className="space-y-4 animate-slide-up">
              <div className="flex items-center gap-2 text-club-500">
                <User size={16} />
                <h3 className="text-xs font-black uppercase tracking-widest tracking-widest">1. Stage Identity</h3>
              </div>
              <div className="space-y-3">
                <input type="text" placeholder="Legal Full Name (Admin Only)" onChange={e => setData({...data, trueName: e.target.value})} className="w-full bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Stage Name (Visible to Club)" onChange={e => setData({...data, streetName: e.target.value})} className="w-full bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="National ID / Passport Number" onChange={e => setData({...data, idNumber: e.target.value})} className="w-full bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Residential Pickup Node" onChange={e => setData({...data, address: e.target.value})} className="w-full bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 animate-slide-up">
              <div className="flex items-center gap-2 text-club-500">
                <Activity size={16} />
                <h3 className="text-xs font-black uppercase tracking-widest tracking-widest">2. Erotic Assets</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input type="text" placeholder="Weight (kg)" onChange={e => setData({...data, physical: {...data.physical!, weight: e.target.value}})} className="bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Height (cm)" onChange={e => setData({...data, physical: {...data.physical!, height: e.target.value}})} className="bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Hair Colour" onChange={e => setData({...data, physical: {...data.physical!, hairColor: e.target.value}})} className="bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Eye Colour" onChange={e => setData({...data, physical: {...data.physical!, eyeColor: e.target.value}})} className="bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
                <input type="text" placeholder="Cup Size" onChange={e => setData({...data, physical: {...data.physical!, breastSize: e.target.value}})} className="col-span-2 bg-neutral-900 border border-white/5 rounded-xl px-4 py-4 text-sm outline-none focus:border-club-500 text-white font-bold" />
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4 animate-slide-up">
              <div className="flex items-center gap-2 text-club-500">
                <ImageIcon size={16} />
                <h3 className="text-xs font-black uppercase tracking-widest tracking-widest">5. Erotic Portfolio</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Stage Clothed', icon: User },
                  { label: 'Seductive Lingerie', icon: Heart },
                  { label: 'Full Frontal', icon: Flame },
                  { label: 'Graphic Action', icon: AlertTriangle },
                  { label: 'VIP Selection', icon: Sparkles }
                ].map(item => (
                  <button key={item.label} className="flex flex-col items-center justify-center aspect-square bg-neutral-900 border-2 border-dashed border-white/10 rounded-2xl hover:border-club-500/50 group transition-all">
                    <item.icon size={24} className="mb-2 text-club-500 group-hover:scale-110 transition-transform" />
                    <span className="text-[8px] font-black uppercase tracking-tighter text-slate-500 text-center px-2">{item.label}</span>
                  </button>
                ))}
              </div>
              <div className="p-4 bg-club-950/20 border border-club-500/20 rounded-xl flex gap-3 items-start shadow-xl">
                 <ShieldCheck size={20} className="text-club-500 shrink-0" />
                 <p className="text-[8px] text-club-200 leading-relaxed uppercase font-black tracking-tighter italic">
                   FANCLUB VETTING: High-resolution media is mandatory. Your portfolio is only visible to the Admin Control Node until manual certification.
                 </p>
              </div>
            </div>
          )}
        </div>

        <div className="absolute bottom-6 left-6 right-6 flex gap-3">
          {step > 1 && <button onClick={prev} className="flex-1 bg-white/5 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] border border-white/5 hover:bg-white/10 text-slate-400">Abort</button>}
          {step < 5 ? (
            <button onClick={next} className="flex-[2] bg-club-600 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-2xl hover:bg-club-500 transition-all text-white">Next Stage Node</button>
          ) : (
            <button onClick={handleSubmit} className="flex-[2] bg-green-600 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-2xl hover:bg-green-500 transition-all text-white">Deploy to FanClub</button>
          )}
        </div>
      </SnakeCard>
    </div>
  );
};

export default TalentRegistration;
