
import React from 'react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-center space-x-1.5 p-1 transform-origin-bottom">
      <div className="w-2 h-4 bg-slate-400 rounded-sm animate-typing-line-1" style={{ animationDelay: '0s' }}></div>
      <div className="w-2 h-5 bg-slate-400 rounded-sm animate-typing-line-2" style={{ animationDelay: '0.15s' }}></div>
      <div className="w-2 h-3 bg-slate-400 rounded-sm animate-typing-line-3" style={{ animationDelay: '0.3s' }}></div>
    </div>
  );
};

export default TypingIndicator;
