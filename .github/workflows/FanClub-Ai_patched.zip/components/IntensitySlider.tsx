
import React from 'react';
import { INTENSITY_LEVELS } from '../constants';
import { Flame } from 'lucide-react';

interface IntensitySliderProps {
  value: number;
  maxUnlocked: number;
  onChange: (val: number) => void;
  onRequestUnlock: (val: number) => void;
}

const IntensitySlider: React.FC<IntensitySliderProps> = ({ value, maxUnlocked, onChange, onRequestUnlock }) => {
  const currentLevel = INTENSITY_LEVELS[value] || INTENSITY_LEVELS[0];

  const handleClick = (level: number) => {
    if (level > maxUnlocked) {
      onRequestUnlock(level);
    } else {
      onChange(level);
    }
  };

  return (
    <div className="w-full">
      <div className="flex justify-between items-end mb-2">
        <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80 flex items-center gap-1.5 italic text-slate-400">
          <Flame size={12} className="text-club-500" /> Heat Level
        </label>
        <span className={`text-[9px] font-black px-2.5 py-1 rounded-full ${currentLevel.color} text-white uppercase tracking-widest shadow-lg shadow-black/40`}>
          {currentLevel.label}
        </span>
      </div>
      
      <div className="flex gap-1.5 h-6">
        {INTENSITY_LEVELS.map((lvl) => {
          const isUnlocked = lvl.level <= maxUnlocked;
          const isActive = lvl.level === value;

          return (
            <button
              key={lvl.level}
              onClick={() => handleClick(lvl.level)}
              className={`
                flex-1 rounded-full transition-all duration-500 relative group
                ${isActive ? lvl.color + ' shadow-[0_0_15px_rgba(244,63,94,0.4)]' : isUnlocked ? 'bg-white/10 hover:bg-white/20' : 'bg-white/5 opacity-20 cursor-not-allowed'}
                ${isActive ? 'scale-y-125 z-10' : 'scale-y-90'}
              `}
            >
              {!isUnlocked && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-0.5 h-0.5 bg-slate-600 rounded-full" />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default IntensitySlider;
