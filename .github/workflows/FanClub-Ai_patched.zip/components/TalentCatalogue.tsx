
import React from 'react';
import { NeuralTalent } from '../types';
import SnakeCard from './SnakeCard';
import { MapPin, Star, Flame, X, ShieldCheck, Heart, Lock, UserCheck } from 'lucide-react';

interface TalentCatalogueProps {
  talentPool: NeuralTalent[];
  onClose: () => void;
  onSelectTalent: (talent: NeuralTalent) => void;
  userLocation: {lat: number, lng: number} | null;
}

const TalentCatalogue: React.FC<TalentCatalogueProps> = ({ talentPool, onClose, onSelectTalent, userLocation }) => {
  const activeTalents = talentPool.filter(t => t.status === 'active');

  const calculateDistance = (talentLoc?: {lat: number, lng: number}) => {
    if (!userLocation || !talentLoc) return "~2.4km";
    // Haversine-ish rough calc for UI
    const R = 6371; // km
    const dLat = (talentLoc.lat - userLocation.lat) * Math.PI / 180;
    const dLon = (talentLoc.lng - userLocation.lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(userLocation.lat * Math.PI / 180) * Math.cos(talentLoc.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const d = R * c;
    return `${d.toFixed(1)}km`;
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black animate-fade-in p-4 overflow-hidden">
      <header className="flex justify-between items-center mb-6 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-club-600/20 rounded-xl flex items-center justify-center text-club-500 border border-club-500/20">
            <Flame size={20} />
          </div>
          <div>
            <h1 className="text-2xl font-black uppercase tracking-tighter text-club-500 neon-text">Performer Gallery</h1>
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest italic gold-text">💃FanClub-Ai™ Exclusives Only</p>
          </div>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors border border-white/10">
          <X size={20} className="text-white" />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {activeTalents.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-600 space-y-4">
            <div className="w-24 h-24 border-2 border-dashed border-slate-800 rounded-full flex items-center justify-center opacity-20">
              <Heart size={48} />
            </div>
            <div className="text-center">
              <p className="text-sm font-black uppercase tracking-widest text-white">Club Currently Dark</p>
              <p className="text-[10px] font-bold uppercase text-slate-500 tracking-tighter mt-1 italic">Performers preparing backstage... check the VIP lounge soon.</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 pb-20">
            {activeTalents.map(t => (
              <div 
                key={t.id} 
                onClick={() => onSelectTalent(t)}
                className="cursor-pointer group animate-slide-up"
              >
                <div className="relative group transition-all duration-500 hover:-translate-y-1">
                  <SnakeCard snakeColor="#f43f5e" padding="p-[1px]" innerClassName="bg-neutral-900 rounded-[2rem] overflow-hidden relative shadow-2xl">
                    <div className="relative aspect-[4/5]">
                      <img 
                        src={`https://image.pollinations.ai/prompt/stunning%20erotic%20adult%20performer%20lingerie%20provocative%208k%20detailed%20skin%20bokeh?seed=${t.id}`} 
                        className="w-full h-full object-cover filter blur-2xl group-hover:blur-sm transition-all duration-1000 scale-125 group-hover:scale-100 opacity-80 group-hover:opacity-100" 
                        alt={t.streetName} 
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent opacity-90" />
                      
                      <div className="absolute inset-0 flex flex-col items-center justify-center group-hover:opacity-0 transition-opacity duration-500">
                         <Lock size={24} className="text-white/10 mb-2" />
                         <span className="text-[8px] font-black uppercase text-white/30 tracking-[0.3em]">VIP Locked</span>
                      </div>

                      <div className="absolute top-4 right-4">
                         <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2 py-1 rounded-full text-[10px] font-black text-gold-500 border border-gold-500/30 shadow-lg">
                           <Star size={10} fill="currentColor" /> {t.rating}
                         </div>
                      </div>

                      <div className="absolute bottom-4 left-4 right-4 space-y-1">
                        <div className="flex items-center gap-1.5">
                           <h3 className="text-base font-black uppercase italic text-white truncate drop-shadow-2xl">{t.streetName}</h3>
                           <UserCheck size={12} className="text-blue-400" />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black text-slate-300 flex items-center gap-1 uppercase tracking-tighter italic opacity-70">
                            <MapPin size={10} className="text-club-500" /> {calculateDistance(t.currentLocation)} Away
                          </span>
                        </div>
                      </div>
                    </div>
                  </SnakeCard>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-full max-w-sm px-4">
        <div className="bg-club-950/40 backdrop-blur-2xl border border-club-500/20 p-4 rounded-[2rem] flex items-center gap-4 shadow-[0_20px_50px_rgba(244,63,94,0.3)]">
           <div className="p-3 bg-club-600 rounded-2xl text-white shadow-lg"><Flame size={20} /></div>
           <div>
              <p className="text-[10px] text-white font-black uppercase tracking-widest italic leading-tight">FanClub-Ai™ Safety Node</p>
              <p className="text-[8px] text-club-200 font-bold uppercase tracking-tighter mt-0.5 opacity-80">
                Encrypted locations. Verified Performers. 100% Discreet.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default TalentCatalogue;
