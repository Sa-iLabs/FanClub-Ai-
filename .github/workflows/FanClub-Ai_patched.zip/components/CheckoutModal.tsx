
import React, { useState } from 'react';
import SnakeCard from './SnakeCard';
import { IKHOKHA_PUBLIC } from '../constants';
import { ikhokaService } from '../services/ikhokha';
import { Lock, CreditCard, ChevronRight, X, CheckCircle2, RefreshCw, AlertCircle, ExternalLink, ShieldCheck, Shield } from 'lucide-react';

interface CheckoutModalProps {
  booking: {
    talent: any;
    duration: number;
    type: string;
    total: number;
    externalId: string;
  };
  onCancel: () => void;
  onConfirm: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ booking, onCancel, onConfirm }) => {
  const [step, setStep] = useState<'details' | 'processing' | 'paylink' | 'success'>('details');
  const [error, setError] = useState<string | null>(null);
  const [paylinkUrl, setPaylinkUrl] = useState<string | null>(null);

  const handlePay = async () => {
    setStep('processing');
    setError(null);
    const amountInCents = Math.round(booking.total * 100);
    const description = `FanClub VIP: ${booking.talent.streetName}`;
    const response = await ikhokaService.createPaymentLink(amountInCents, description, booking.externalId);

    if (response && response.paylinkUrl) {
      setPaylinkUrl(response.paylinkUrl);
      setStep('paylink');
    } else {
      setError("Handshake Failed. Merchant Node Unreachable. Try again.");
      setStep('details');
    }
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/95 backdrop-blur-3xl animate-fade-in">
      <SnakeCard snakeColor="#fbbf24" className="w-full max-w-sm" innerClassName="bg-neutral-950 p-6 flex flex-col gap-6 border border-gold-900/30 shadow-[0_0_60px_rgba(251,191,36,0.15)]">
        {step === 'details' && (
          <div className="animate-fade-in space-y-6">
            <div className="flex justify-between items-center">
               <div className="flex items-center gap-3">
                 <div className="w-14 h-14 bg-[#fbbf24] rounded-2xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(251,191,36,0.4)] font-black text-3xl italic">
                   iK
                 </div>
                 <div>
                   <h2 className="text-sm font-black uppercase tracking-widest text-white italic leading-none">Checkout Node</h2>
                   <p className="text-[8px] text-gold-500 font-bold uppercase tracking-widest mt-1">Payments by iKhokha Gateway</p>
                 </div>
               </div>
               <button onClick={onCancel} className="p-2 text-slate-500 hover:text-white transition-colors"><X size={20} /></button>
            </div>

            {error && (
              <div className="bg-red-950/20 border border-red-500/30 p-3 rounded-xl flex items-center gap-2 text-red-500 text-[9px] font-black uppercase">
                <AlertCircle size={14} /> {error}
              </div>
            )}

            <div className="bg-neutral-900/80 rounded-3xl p-6 border border-white/5 space-y-5 shadow-inner">
               <div className="flex justify-between items-center border-b border-white/5 pb-4">
                  <div>
                    <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-1">Session ID</p>
                    <p className="text-xs font-black text-white italic">{booking.talent.streetName} VIP</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-1">Time</p>
                    <p className="text-xs font-black text-white">{booking.duration}m</p>
                  </div>
               </div>
               <div className="flex justify-between items-center">
                  <div className="flex flex-col">
                    <p className="text-[11px] font-black uppercase text-gold-500 gold-text">Settlement</p>
                    <p className="text-[8px] text-slate-500 font-bold uppercase">Incl. Bouncer & Uber</p>
                  </div>
                  <p className="text-3xl font-black text-white italic">R {booking.total.toLocaleString()}</p>
               </div>
            </div>

            <button onClick={handlePay} className="w-full bg-[#fbbf24] py-5 rounded-[2rem] font-black uppercase text-[13px] text-black shadow-2xl shadow-gold-900/40 flex items-center justify-center gap-3 active:scale-95 transition-all hover:bg-gold-500">
               Generate iKhokha Paylink <ChevronRight size={18} />
            </button>

            <div className="pt-4 flex flex-col items-center gap-3 border-t border-white/10">
              <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10">
                <Shield size={10} className="text-gold-500" />
                <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 italic">
                  {IKHOKHA_PUBLIC.brandingText}
                </p>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 bg-[#fbbf24] rounded-lg flex items-center justify-center text-xs text-black font-black italic">iK</div>
                <span className="text-base font-black text-white tracking-tighter">iKhokha©</span>
              </div>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-24 flex flex-col items-center justify-center gap-8 text-center animate-pulse">
             <div className="relative">
                <RefreshCw size={64} className="text-[#fbbf24] animate-spin-slow" />
                <div className="absolute inset-0 flex items-center justify-center font-black text-2xl text-gold-500 italic">iK</div>
             </div>
             <div className="space-y-2">
                <h3 className="text-xl font-black uppercase text-white italic tracking-tighter">Syncing Merchant Hub</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em]">Verifying Secure Signature...</p>
             </div>
          </div>
        )}

        {step === 'paylink' && (
          <div className="animate-fade-in space-y-8 py-6">
             <div className="text-center space-y-3">
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto border border-green-500/30">
                  <ShieldCheck size={48} className="text-green-500" />
                </div>
                <h3 className="text-xl font-black uppercase text-white italic tracking-tighter">Handshake Complete</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Paylink Authenticated by iKhokha</p>
             </div>
             <a href={paylinkUrl!} target="_blank" rel="noopener noreferrer" className="w-full bg-[#fbbf24] py-5 rounded-[2rem] font-black uppercase text-[13px] text-black shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all">
                Launch Secure Checkout <ExternalLink size={18} />
             </a>
             <div className="flex flex-col items-center gap-2">
               <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-600">
                 Secure Matrix Node Active
               </p>
               <div className="flex items-center gap-1.5 opacity-50">
                 <p className="text-[7px] font-black uppercase text-slate-500">Payments Powered by:</p>
                 <div className="w-3 h-3 bg-[#fbbf24] rounded-xs flex items-center justify-center text-[7px] text-black font-black italic">iK</div>
               </div>
             </div>
          </div>
        )}
      </SnakeCard>
    </div>
  );
};

export default CheckoutModal;
