
import React, { useState } from 'react';
import SnakeCard from './SnakeCard';
import { User, ShieldCheck, Calendar, X, Heart, ShieldAlert, Star } from 'lucide-react';

interface UserOnboardingProps {
  onClose: () => void;
  onComplete: (dob: string) => void;
}

const UserOnboarding: React.FC<UserOnboardingProps> = ({ onClose, onComplete }) => {
  const [dob, setDob] = useState('');
  const [nickname, setNickname] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (dob && nickname) {
      onComplete(dob);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex flex-col bg-black animate-fade-in p-4 overflow-hidden">
      <SnakeCard snakeColor="#fbbf24" className="flex-1" innerClassName="bg-neutral-950 p-8 flex flex-col">
        <header className="flex justify-between items-center mb-8 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gold-600/20 rounded-xl flex items-center justify-center text-gold-500">
              <Star size={20} />
            </div>
            <div>
              <h1 className="text-xl font-black uppercase tracking-tighter text-gold-500 gold-text">VIP Lounge Entry</h1>
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">John & Jill Membership Registration</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full">
            <X size={20} className="text-white/50" />
          </button>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center max-w-sm mx-auto w-full space-y-8">
           <div className="text-center space-y-2">
              <ShieldAlert size={40} className="text-club-500 mx-auto animate-pulse" />
              <h2 className="text-lg font-black uppercase text-white tracking-tighter">Adult Certification</h2>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-tighter leading-relaxed">
                💃FanClub-Ai™ is a strictly 18+ adult playground. <br/>Enter your discreet credentials to join the inner circle.
              </p>
           </div>

           <form onSubmit={handleSubmit} className="w-full space-y-5">
              <div className="space-y-1.5">
                 <label className="text-[9px] font-black uppercase text-slate-500 ml-2 tracking-widest">Discreet Nickname</label>
                 <input 
                   type="text" 
                   value={nickname}
                   onChange={e => setNickname(e.target.value)}
                   placeholder="e.g. VIP_GUEST_99"
                   className="w-full bg-neutral-900 border border-white/10 rounded-xl px-4 py-4 text-sm focus:border-gold-500 outline-none transition-all placeholder:text-slate-700 font-bold"
                   required
                 />
              </div>

              <div className="space-y-1.5">
                 <label className="text-[9px] font-black uppercase text-slate-500 ml-2 tracking-widest">Birth Date (Verified 18+)</label>
                 <input 
                   type="date" 
                   value={dob}
                   onChange={e => setDob(e.target.value)}
                   className="w-full bg-neutral-900 border border-white/10 rounded-xl px-4 py-4 text-sm focus:border-gold-500 outline-none text-white font-bold"
                   required
                 />
              </div>

              <div className="p-4 bg-gold-950/20 rounded-2xl border border-gold-500/20 flex gap-3">
                 <ShieldCheck size={20} className="text-gold-500 shrink-0" />
                 <p className="text-[9px] text-gold-200 font-bold uppercase leading-relaxed tracking-tighter">
                    I certify that I am of legal age and consent to explicit adult entertainment. My privacy is protected by 💃FanClub-Ai™ encryption.
                 </p>
              </div>

              <button 
                type="submit" 
                className="w-full bg-gold-600 py-4 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg shadow-gold-900/40 hover:bg-gold-500 transition-all active:scale-95 text-black"
              >
                Claim Membership Card
              </button>
           </form>
        </div>

        <div className="mt-8 flex justify-center items-center gap-2 opacity-30">
           <Heart size={10} className="text-club-500" />
           <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest italic">💃FanClub-Ai™ | Your Erotic Dreams Cum True</p>
        </div>
      </SnakeCard>
    </div>
  );
};

export default UserOnboarding;
