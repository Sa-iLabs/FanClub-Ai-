import { Brand } from './types';

// OpenRouter Configuration (Uncensored / High-Performance Models)
export const OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions";
export const DEFAULT_MODEL = "liquid/lfm-40b"; // Using a high-performance unrestricted model via OpenRouter

// iKhokha Public (safe-to-ship) Configuration
export const IKHOKHA_PUBLIC = {
  discreetDescriptor: "SA-iLabs Digital Svcs",
  brandingText: "Payments are Powered by: IKHOKHA",
  apiVersion: "v1"
};

export const BRAND_THEMES: Record<Brand, any> = {
  [Brand.VIP]: {
    bg: 'bg-slate-950',
    cardBg: 'bg-slate-900/80',
    text: 'text-slate-100',
    accent: 'text-rose-500',
    button: 'bg-rose-600 hover:bg-rose-500 text-white',
    chatBubbleAi: 'bg-slate-800 text-slate-100 border border-slate-700/50',
    chatBubbleUser: 'bg-rose-600 text-white',
    snakeColor: '#e11d48'
  },
  [Brand.Neon]: {
    bg: 'bg-black',
    cardBg: 'bg-zinc-900/80',
    text: 'text-zinc-100',
    accent: 'text-club-500',
    button: 'bg-club-600 hover:bg-club-500 text-white',
    chatBubbleAi: 'bg-zinc-800 text-zinc-100 border border-zinc-700/50',
    chatBubbleUser: 'bg-club-600 text-white',
    snakeColor: '#f43f5e'
  },
  [Brand.Gold]: {
    bg: 'bg-neutral-950',
    cardBg: 'bg-neutral-900/80',
    text: 'text-neutral-100',
    accent: 'text-gold-500',
    button: 'bg-gold-600 hover:bg-gold-500 text-black',
    chatBubbleAi: 'bg-neutral-800 text-neutral-100 border border-neutral-700/50',
    chatBubbleUser: 'bg-gold-600 text-black',
    snakeColor: '#fbbf24'
  }
};

export const INTENSITY_LEVELS = [
  { level: 0, label: "Romantic", color: "bg-blue-500" },
  { level: 1, label: "Flirtatious", color: "bg-cyan-500" },
  { level: 2, label: "Passionate", color: "bg-emerald-500" },
  { level: 3, label: "Seductive", color: "bg-amber-500" },
  { level: 4, label: "Erotic", color: "bg-orange-500" },
  { level: 5, label: "Explicit", color: "bg-rose-500" },
  { level: 6, label: "Hardcore", color: "bg-red-600" },
  { level: 7, label: "Nympho-Mode", color: "bg-purple-700" },
];