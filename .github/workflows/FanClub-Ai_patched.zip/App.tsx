import React, { useState, useEffect, useRef } from 'react';
import { Brand, Message, PersonaType, UserSettings, PersonaAttributes, ImageSettings, NeuralTalent, Booking, FinancialRecord } from './types';
import { BRAND_THEMES, IKHOKHA_PUBLIC } from './constants';
import { apiService } from './services/api';
import { ikhokaService } from './services/ikhokha';
import { soundService } from './utils/soundService';
import ConsentModal from './components/ConsentModal';
import IntensitySlider from './components/IntensitySlider';
import SnakeCard from './components/SnakeCard';
import SnakeBorder from './components/SnakeBorder';
import NeuralAssistant from './components/NeuralAssistant';
import SettingsModal from './components/SettingsModal';
import PersonaSettingsModal from './components/PersonaSettingsModal';
import TypingIndicator from './components/TypingIndicator';
import AdminPortal from './components/AdminPortal';
import TalentCatalogue from './components/TalentCatalogue';
import UserOnboarding from './components/UserOnboarding';
import PerformerProfile from './components/PerformerProfile';
import CheckoutModal from './components/CheckoutModal';
import TalentRegistration from './components/TalentRegistration';
import { Send, Heart, Briefcase, User, Settings, Trash2, Compass, Star, Lock, Flame, ShieldCheck, Sparkles, UserPlus, MapPin } from 'lucide-react';

const LOCAL_DEVICE_ID = "fanclub_node_v2"; 

const PERSONA_OPTS = [
  { type: PersonaType.Nympho, icon: <Flame size={14} />, label: "Nympho" },
  { type: PersonaType.Girlfriend, icon: <Heart size={14} />, label: "Girlfriend" },
  { type: PersonaType.Boyfriend, icon: <User size={14} />, label: "Boyfriend" },
  { type: PersonaType.Companion, icon: <Compass size={14} />, label: "Companion" },
  { type: PersonaType.Consultant, icon: <Briefcase size={14} />, label: "Consultant" },
  { type: PersonaType.Custom, icon: <Sparkles size={14} />, label: "Custom" },
];

const DEFAULT_ATTRS: PersonaAttributes = {
  friendly: 10, kind: 10, strong: 0, annoyed: 0, kinky: 10, sexy: 10, amorous: 10, horny: 10, forward: 10, cursing: 10, naughty: 10, foulLanguage: 10, dirtyTalk: 10, seductive: 10, approachable: 10, direct: 10, secretive: 0, rude: 0, needy: 10, dominant: 0, submissive: 10, dynamic: 'partner', gender: 'female', orientation: 'straight', age: 24
};

const SEED_TALENT: NeuralTalent[] = [
  {
    id: 'T-001',
    trueName: 'Sarah Jenkins',
    streetName: 'Lola Blue',
    idNumber: '9201010000000',
    address: 'Sandton, GP',
    bankAccount: { bank: 'FNB', branchCode: '250655', accountNumber: '62000000000', accountType: 'Savings' },
    physical: { weight: '55kg', height: '170cm', hairColor: 'Blonde', eyeColor: 'Blue', breastSize: '34C' },
    preferences: { fantasies: 'Roleplay, Power Dynamics', abilities: 'Expert Dirty Talk', likes: 'Fine Dining', dislikes: 'Rudeness', noGoZones: 'Face', noGoActions: 'Violence' },
    portfolio: { clothed: [], underwear: [], fullFrontal: [], explicit: [], chosenErotic: [] },
    status: 'active',
    rating: 4.9,
    currentLocation: { lat: -26.1076, lng: 28.0567 } 
  },
  {
    id: 'T-002',
    trueName: 'Jessica Van Wyk',
    streetName: 'Roxy Red',
    idNumber: '9502020000000',
    address: 'Cape Town, WC',
    bankAccount: { bank: 'Standard Bank', branchCode: '051001', accountNumber: '10100000000', accountType: 'Current' },
    physical: { weight: '62kg', height: '165cm', hairColor: 'Red', eyeColor: 'Green', breastSize: '36D' },
    preferences: { fantasies: 'Outdoor play', abilities: 'Flexibility', likes: 'Champagne', dislikes: 'Cheap talk', noGoZones: 'None', noGoActions: 'None' },
    portfolio: { clothed: [], underwear: [], fullFrontal: [], explicit: [], chosenErotic: [] },
    status: 'active',
    rating: 5.0,
    currentLocation: { lat: -33.9249, lng: 18.4241 } 
  }
];

const App: React.FC = () => {
  const [view, setView] = useState<'chat' | 'admin' | 'catalogue' | 'user-onboarding' | 'profile' | 'registration'>('chat');
  const [brand, setBrand] = useState<Brand>(() => (localStorage.getItem('fanclub_brand') as Brand) || Brand.VIP);
  const [messages, setMessages] = useState<Message[]>(() => JSON.parse(localStorage.getItem('fanclub_history') || '[]'));
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [persona, setPersona] = useState<PersonaType>(() => (localStorage.getItem('fanclub_persona') as PersonaType) || PersonaType.Girlfriend);
  const [intensity, setIntensity] = useState(() => Number(localStorage.getItem('fanclub_intensity') || '0'));
  
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem('fanclub_settings');
    if (saved) return JSON.parse(saved);
    return {
      userId: LOCAL_DEVICE_ID, dob: '', isConsentGiven: false, isRegistered: false, isVetted: false, enableAutoVoice: true, enableAutoImage: true, enableSFX: true, preferredVoice: 'Kore', voiceProvider: 'native', unlockedLevel: 4,
      imageSettings: { width: 1024, height: 1024, aspectRatio: '1:1' },
      personaConfig: { [PersonaType.Nympho]: DEFAULT_ATTRS }
    };
  });

  const [talentPool, setTalentPool] = useState<NeuralTalent[]>(() => {
    const saved = localStorage.getItem('fanclub_talent');
    return saved ? JSON.parse(saved) : SEED_TALENT;
  });
  const [bookings, setBookings] = useState<Booking[]>(() => JSON.parse(localStorage.getItem('fanclub_bookings') || '[]'));
  const [ledger, setLedger] = useState<FinancialRecord[]>(() => JSON.parse(localStorage.getItem('fanclub_ledger') || '[]'));
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  
  const [showConsent, setShowConsent] = useState(false);
  const [targetIntensity, setTargetIntensity] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [showPersonaSettings, setShowPersonaSettings] = useState(false);
  const [selectedTalent, setSelectedTalent] = useState<NeuralTalent | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [currentBooking, setCurrentBooking] = useState<any>(null);
  const [isAssistantMode, setIsAssistantMode] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);

    // Handle iKhokha return / redirect status (best-effort; webhook is the source of truth)
  useEffect(() => {
    try {
      if (typeof window === 'undefined') return;
      const url = new URL(window.location.href);
      const payment = url.searchParams.get('payment');
      const ref = url.searchParams.get('ref') || url.searchParams.get('externalTransactionID');

      if (!payment || !ref) return;

      // Strip params to avoid duplicate processing on refresh
      url.searchParams.delete('payment');
      url.searchParams.delete('ref');
      url.searchParams.delete('externalTransactionID');
      window.history.replaceState({}, document.title, url.toString());

      (async () => {
        const status = await ikhokaService.checkStatus(ref);
        if (status.status === 'paid') {
          setMessages(prev => [...prev, {
            id: `sys-pay-${Date.now()}`,
            role: 'system',
            content: `✅ Payment confirmed for transaction ${ref}. Your booking is now secured.`
          }]);
        } else if (status.status === 'pending') {
          setMessages(prev => [...prev, {
            id: `sys-pay-${Date.now()}`,
            role: 'system',
            content: `⏳ Payment is still pending for transaction ${ref}. If you already paid, it may take a minute to reflect.`
          }]);
        } else if (status.status === 'failed') {
          setMessages(prev => [...prev, {
            id: `sys-pay-${Date.now()}`,
            role: 'system',
            content: `❌ Payment failed for transaction ${ref}. Please try again or choose another method.`
          }]);
        }
      })();
    } catch (e) {
      console.error('Payment return handler failed', e);
    }
  }, []);

useEffect(() => {
    localStorage.setItem('fanclub_history', JSON.stringify(messages));
    localStorage.setItem('fanclub_settings', JSON.stringify(settings));
    localStorage.setItem('fanclub_talent', JSON.stringify(talentPool));
    localStorage.setItem('fanclub_bookings', JSON.stringify(bookings));
    localStorage.setItem('fanclub_ledger', JSON.stringify(ledger));
    localStorage.setItem('fanclub_brand', brand);
    localStorage.setItem('fanclub_intensity', intensity.toString());
    localStorage.setItem('fanclub_persona', persona);
  }, [messages, settings, talentPool, bookings, ledger, brand, intensity, persona]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => console.warn("Location access denied")
      );
    }
  }, []);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;
    
    soundService.play('send', settings.enableSFX);
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    try {
      const res = await apiService.sendPrompt(
        settings.userId,
        persona,
        intensity,
        currentInput,
        undefined,
        undefined,
        settings.personaConfig?.[persona]
      );

      if (res.status === 'ok' && res.reply) {
        soundService.play('receive', settings.enableSFX);
        const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'ai', text: res.reply, timestamp: Date.now() };
        
        if (settings.enableAutoImage && (intensity >= 4 || Math.random() > 0.8)) {
          const imgUrl = await apiService.generateImage(persona, intensity, settings.personaConfig?.[persona] as any);
          if (imgUrl) aiMsg.imageUrl = imgUrl;
        }

        setMessages(prev => [...prev, aiMsg]);
        if (settings.enableAutoVoice) apiService.generateSpeech(res.reply, settings, intensity);
      }
    } catch (error) {
      console.error(error);
      soundService.play('error', settings.enableSFX);
    } finally {
      setIsLoading(false);
    }
  };

  const handleIntensityChange = (val: number) => {
    if (val > settings.unlockedLevel && !settings.isConsentGiven) {
      setTargetIntensity(val);
      setShowConsent(true);
    } else {
      setIntensity(val);
    }
  };

  const theme = BRAND_THEMES[brand];

  const renderView = () => {
    switch (view) {
      case 'admin':
        return <AdminPortal onClose={() => setView('chat')} talentPool={talentPool} setTalentPool={setTalentPool} bookings={bookings} setBookings={setBookings} ledger={ledger} setLedger={setLedger} userLocation={userLocation} />;
      case 'catalogue':
        return <TalentCatalogue talentPool={talentPool} onClose={() => setView('chat')} onSelectTalent={(t) => { setSelectedTalent(t); setView('profile'); }} userLocation={userLocation} />;
      case 'profile':
        return <PerformerProfile talent={selectedTalent!} onClose={() => setView('catalogue')} onBook={(d, t) => { setCurrentBooking({talent: selectedTalent, duration: d, type: t, total: t === 'interaction' ? 1500 : d*10, externalId: `bk_${Date.now()}`}); setShowCheckout(true); }} hasKey={true} onOpenKey={() => setShowSettings(true)} />;
      case 'user-onboarding':
        return <UserOnboarding onClose={() => setView('chat')} onComplete={(dob) => { setSettings(p => ({...p, dob, isRegistered: true})); setView('chat'); }} />;
      case 'registration':
        return <TalentRegistration onClose={() => setView('chat')} onRegister={(t) => { setTalentPool(p => [...p, t]); setView('chat'); }} />;
      default:
        return (
          <div className="flex flex-col h-full w-full relative overflow-hidden bg-black">
            {/* Fix UI Alignment: Header fixed at top with safe-area padding */}
            <header className="shrink-0 z-30 pt-[env(safe-area-inset-top)]">
              <SnakeCard snakeColor={isAssistantMode ? '#8b5cf6' : theme.snakeColor} innerClassName={`${theme.cardBg} flex flex-col`} padding="p-[2px]">
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
                  <div className="flex flex-col cursor-pointer" onClick={() => setView('admin')}>
                    <h1 className="text-xl font-black uppercase tracking-tighter neon-text italic leading-none">💃FanClub-Ai™</h1>
                    <span className={`text-[8px] uppercase font-black tracking-[0.2em] ${theme.accent} opacity-80 italic mt-1`}>Secure Performer Matrix</span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setIsAssistantMode(!isAssistantMode)} className={`p-2 rounded-full transition-all ${isAssistantMode ? 'bg-violet-600 text-white' : 'bg-white/5 text-slate-400'}`} title="Neural Assistant">
                      <Sparkles size={16} />
                    </button>
                    <button onClick={() => setView('catalogue')} className="p-2 bg-white/5 hover:bg-club-500/20 text-club-500 rounded-full border border-club-500/10 transition-colors">
                      <Compass size={16} />
                    </button>
                    <button onClick={() => setShowSettings(true)} className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-slate-400">
                      <Settings size={16} />
                    </button>
                  </div>
                </div>
                {!isAssistantMode && (
                  <div className="px-4 py-3 space-y-3 animate-fade-in bg-black/20">
                    <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-1">
                      {PERSONA_OPTS.map(p => (
                        <button key={p.type} onClick={() => setPersona(p.type)} className={`shrink-0 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider border transition-all ${persona === p.type ? `bg-white/10 ${theme.accent} border-white/20 shadow-md` : 'opacity-40 border-transparent text-slate-400'}`}>{p.label}</button>
                      ))}
                    </div>
                    <IntensitySlider value={intensity} maxUnlocked={settings.unlockedLevel} onChange={handleIntensityChange} onRequestUnlock={(lvl) => { setTargetIntensity(lvl); setShowConsent(true); }} />
                  </div>
                )}
              </SnakeCard>
            </header>

            {/* Content Area: Adjusted for better scrolling and flex growth */}
            <main className="flex-1 overflow-y-auto px-2 py-4 space-y-4 custom-scrollbar bg-black/40 relative border-x border-white/5 scroll-smooth">
              {isAssistantMode ? (
                <NeuralAssistant theme={theme} onClose={() => setIsAssistantMode(false)} settings={settings} currentPersona={persona} currentIntensity={intensity} />
              ) : (
                <div className="flex flex-col gap-4 pb-24">
                  {messages.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-20 opacity-20 pointer-events-none">
                      <Flame size={48} className="mb-4" />
                      <p className="text-[10px] font-black uppercase tracking-[0.3em]">Uplink Active. Awaiting Desires.</p>
                    </div>
                  )}
                  {messages.map(m => (
                    <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}>
                      <div className={`max-w-[85%] space-y-2`}>
                        <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-lg ${m.role === 'user' ? theme.chatBubbleUser + ' rounded-tr-none' : (m.role === 'system' ? 'bg-indigo-900/30 border border-indigo-500/50 text-indigo-100 text-[10px] font-bold uppercase text-center w-full' : theme.chatBubbleAi + ' rounded-tl-none')}`}>
                          {m.isLoadingMessage ? <TypingIndicator /> : <p className="whitespace-pre-wrap">{m.text}</p>}
                        </div>
                        {m.imageUrl && (
                          <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl max-w-[280px]">
                            <img src={m.imageUrl} alt="Neural Render" className="w-full h-auto object-cover" loading="lazy" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start animate-slide-up">
                      <div className={`${theme.chatBubbleAi} px-4 py-3 rounded-2xl rounded-tl-none shadow-lg`}>
                        <TypingIndicator />
                      </div>
                    </div>
                  )}
                  <div ref={scrollRef} />
                </div>
              )}
            </main>

            {/* Footer Input: Fixed at bottom with safe-area padding */}
            <footer className="shrink-0 z-30 p-2 space-y-2 bg-black/80 backdrop-blur-lg border-t border-white/5 pb-[env(safe-area-inset-bottom)]">
              <div className="flex justify-center gap-2 mb-1">
                <button onClick={() => setView('registration')} className="text-[8px] font-black uppercase text-club-500 bg-club-500/10 px-3 py-1 rounded-full border border-club-500/20 hover:bg-club-500/20 transition-all flex items-center gap-1.5">
                  <UserPlus size={10} /> Performer Uplink
                </button>
                <button onClick={() => setView('user-onboarding')} className="text-[8px] font-black uppercase text-gold-500 bg-gold-500/10 px-3 py-1 rounded-full border border-gold-500/20 hover:bg-gold-500/20 transition-all flex items-center gap-1.5">
                  <Star size={10} /> VIP Lounge
                </button>
              </div>
              <SnakeBorder snakeColor={theme.snakeColor} cornerRadius="rounded-xl">
                <div className={`flex items-center gap-1 p-1 ${theme.cardBg} backdrop-blur-xl rounded-xl`}>
                  <button onClick={() => { if(confirm("Purge Neural Records?")) setMessages([]); }} className="p-2.5 text-red-500/40 hover:text-red-500 transition-colors" title="Purge Memory"><Trash2 size={18} /></button>
                  <input className="flex-1 bg-transparent px-2 py-2.5 outline-none text-sm font-medium text-white placeholder:text-slate-600" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} placeholder="Speak Your Desires..." disabled={isLoading} />
                  <button onClick={handleSendMessage} disabled={!input.trim() || isLoading} className={`p-2.5 rounded-lg ${theme.button} active:scale-95 transition-all shadow-lg flex items-center justify-center`}><Send size={18} /></button>
                </div>
              </SnakeBorder>
              <div className="flex justify-center items-center gap-2 opacity-20 mt-1">
                 <p className="text-[6px] font-black uppercase text-slate-500 tracking-[0.3em] italic">{IKHOKHA_PUBLIC.brandingText}</p>
                 <div className="w-2.5 h-2.5 bg-[#fbbf24] rounded-[2px] flex items-center justify-center text-[6px] text-black font-black italic">iK</div>
              </div>
            </footer>
          </div>
        );
    }
  };

  return (
    <div className={`flex flex-col h-[100dvh] w-full overflow-hidden font-sans transition-colors duration-700 ${theme.bg} ${theme.text}`}>
      {renderView()}
      
      <ConsentModal isOpen={showConsent} targetLevel={targetIntensity} onConfirm={(dob) => { setSettings(p => ({ ...p, dob, isConsentGiven: true })); setIntensity(targetIntensity); setShowConsent(false); }} onCancel={() => setShowConsent(false)} />
      
      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        enableAutoVoice={settings.enableAutoVoice} 
        enableAutoImage={settings.enableAutoImage} 
        enableSFX={settings.enableSFX} 
        imageSettings={settings.imageSettings!} 
        preferredVoice={settings.preferredVoice} 
        voiceProvider={settings.voiceProvider} 
        onSaveKeys={(av, ai, sfx, pv, vp, vi, img) => { setSettings(s => ({ ...s, enableAutoVoice: av, enableAutoImage: ai, enableSFX: sfx, preferredVoice: pv, voiceProvider: vp, voiceId: vi, imageSettings: img })); }} 
      />
      
      {showCheckout && currentBooking && (
        <CheckoutModal 
          booking={currentBooking} 
          onCancel={() => setShowCheckout(false)} 
          onConfirm={() => {
            const newBooking = { id: currentBooking.externalId, talentId: currentBooking.talent.id, userId: settings.userId, timestamp: Date.now(), duration: currentBooking.duration, totalAmount: currentBooking.total, travelFee: 150, status: 'paid' as const };
            setBookings(prev => [...prev, newBooking]);
            
            const newRecord = { id: `L-${Date.now()}`, date: new Date().toISOString(), type: 'income' as const, amount: currentBooking.total, description: `VIP Interaction - ${currentBooking.talent.streetName}`, category: 'Service' as const };
            setLedger(prev => [...prev, newRecord]);

            setShowCheckout(false);
            setCurrentBooking(null);
            setView('chat');
            setMessages(m => [...m, {id: Date.now().toString(), role: 'system', text: `💳 Settlement Verified. VIP interaction with ${currentBooking.talent.streetName} initialized. Escort logistics synchronized.`, timestamp: Date.now()}]);
          }} 
        />
      )}
    </div>
  );
};

export default App;