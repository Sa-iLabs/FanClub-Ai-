
class SoundService {
  private ctx: AudioContext | null = null;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  private createGain(startTime: number, duration: number, startVal: number, endVal: number) {
    const gain = this.ctx!.createGain();
    gain.gain.setValueAtTime(startVal, startTime);
    gain.gain.exponentialRampToValueAtTime(endVal, startTime + duration);
    return gain;
  }

  play(type: 'click' | 'send' | 'receive' | 'error', enabled: boolean = true) {
    if (!enabled) return;
    this.init();
    if (this.ctx!.state === 'suspended') {
      this.ctx!.resume();
    }

    const now = this.ctx!.currentTime;

    switch (type) {
      case 'click': {
        const osc = this.ctx!.createOscillator();
        const gain = this.createGain(now, 0.1, 0.1, 0.001);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.1);
        osc.connect(gain).connect(this.ctx!.destination);
        osc.start(now);
        osc.stop(now + 0.1);
        break;
      }
      case 'send': {
        const osc = this.ctx!.createOscillator();
        const gain = this.createGain(now, 0.2, 0.1, 0.001);
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.exponentialRampToValueAtTime(900, now + 0.2);
        osc.connect(gain).connect(this.ctx!.destination);
        osc.start(now);
        osc.stop(now + 0.2);
        break;
      }
      case 'receive': {
        // Soft double-ping
        const playTone = (freq: number, startTime: number) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.createGain(startTime, 0.3, 0.05, 0.001);
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, startTime);
          osc.connect(gain).connect(this.ctx!.destination);
          osc.start(startTime);
          osc.stop(startTime + 0.3);
        };
        playTone(1046.50, now); // C6
        playTone(1318.51, now + 0.1); // E6
        break;
      }
      case 'error': {
        const osc = this.ctx!.createOscillator();
        const gain = this.createGain(now, 0.3, 0.1, 0.001);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.linearRampToValueAtTime(50, now + 0.3);
        osc.connect(gain).connect(this.ctx!.destination);
        osc.start(now);
        osc.stop(now + 0.3);
        break;
      }
    }
  }
}

export const soundService = new SoundService();
