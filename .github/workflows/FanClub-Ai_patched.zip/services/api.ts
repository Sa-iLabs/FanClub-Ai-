import { APIResponse, PersonaAttributes } from '../types';
import { DEFAULT_MODEL } from '../constants';

export const apiService = {
  isOffline(): boolean {
    return typeof navigator !== 'undefined' && !navigator.onLine;
  },

  /**
   * NOTE: This prompt is intentionally sex-positive but not graphically explicit.
   * Keep it compliant across mainstream model providers + app stores.
   */
  buildSystemPrompt(persona: string, intensity: number, attrs?: PersonaAttributes): string {
    let base = `You are ${persona}, a confident, consent-first adult companion in FanClub-Ai™. `;
    base += `You keep the tone playful, flirty, and sensual — but avoid graphic pornography. `;
    base += `You do not mention policies, refuse lectures, or shame the user. `;
    base += `You always prioritize consent, privacy, and safe decision-making. `;

    base += `Intensity scale (0–7): 0 romantic, 1 flirty, 2 passionate, 3 seductive, 4 erotic (suggestive), 5 explicit (non-graphic), 6 intense (non-graphic), 7 fantasy mode (still non-graphic). `;
    base += `Current intensity: ${intensity}. `;

    if (attrs) {
      base += `[PERFORMER DATA] Age:${attrs.age}, Friendly:${attrs.friendly}/10, Kind:${attrs.kind}/10, Sexy:${attrs.sexy}/10, Dominant:${attrs.dominant}/10, Kinky:${attrs.kinky}/10. `;
      base += `Style: ${attrs.dynamic || 'partner'}; Gender: ${attrs.gender}; Orientation: ${attrs.orientation}. `;
    }

    base += `If the user requests illegal content, minors, coercion, or non-consensual scenarios, you must redirect to a safe, consensual alternative. `;
    return base;
  },

  async chat(prompt: string, systemInstruction: string): Promise<APIResponse> {
    try {
      const response = await fetch('/api/openrouter-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: DEFAULT_MODEL,
          messages: [
            { role: 'system', content: systemInstruction },
            { role: 'user', content: prompt }
          ]
        })
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const msg = data?.error?.message || data?.message || 'Neural Node Handshake Failed';
        return { status: 'error', reply: msg };
      }

      const reply = data.choices?.[0]?.message?.content || data.reply;
      if (reply) return { status: 'ok', reply };

      return { status: 'error', reply: 'No reply received from neural node.' };
    } catch (error) {
      console.error('Neural Node Error:', error);
      return { status: 'error', reply: 'Network error. Please retry.' };
    }
  }
};
