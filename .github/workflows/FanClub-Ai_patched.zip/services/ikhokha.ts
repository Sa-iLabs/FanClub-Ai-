import { IKHOKHA_PUBLIC } from '../constants';

export interface PayLinkRequest {
  entityID: string;
  externalEntityID?: string;
  amount: number; // in cents
  currency: string;
  requesterUrl: string;
  mode: 'live' | 'test';
  description?: string;
  externalTransactionID: string;
  urls: {
    callbackUrl: string;
    successPageUrl: string;
    failurePageUrl: string;
  };
}

export interface PayLinkResponse {
  paylinkUrl?: string;
  paylinkID?: string;
  status?: string;
  message?: string;
  [key: string]: any;
}

export interface PayStatusResponse {
  status: 'paid' | 'pending' | 'failed' | 'unknown';
  raw?: any;
}

function assertOk(res: Response) {
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

export const ikhokaService = {
  /**
   * Create a paylink via your server-side /api function.
   * IMPORTANT: secrets must live in server env vars, never in the browser.
   */
  async createPayLink(payload: PayLinkRequest): Promise<PayLinkResponse | null> {
    try {
      const res = await fetch('/api/ikhokha-create-paylink', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      assertOk(res);
      return await res.json();
    } catch (err) {
      console.error('iKhokha createPayLink failed', err);
      return null;
    }
  },

  /**
   * Check payment status via your server-side /api function.
   */
  async checkStatus(externalTransactionID: string): Promise<PayStatusResponse> {
    try {
      const res = await fetch(`/api/ikhokha-status?ref=${encodeURIComponent(externalTransactionID)}`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });
      assertOk(res);
      return await res.json();
    } catch (err) {
      console.error('iKhokha status failed', err);
      return { status: 'unknown' };
    }
  },

  getBrandingText(): string {
    return IKHOKHA_PUBLIC.brandingText;
  }
};
