
export enum Brand {
  VIP = 'VIP_Lounge',
  Neon = 'Neon_Night',
  Gold = 'Gold_Member'
}

export enum PersonaType {
  Boyfriend = 'Boyfriend',
  Girlfriend = 'Girlfriend',
  Companion = 'Companion',
  Consultant = 'Consultant',
  Custom = 'Custom',
  Nympho = 'Nympho'
}

export interface Message {
  id: string;
  role: 'user' | 'ai' | 'system';
  text: string;
  imageUrl?: string;
  videoUrl?: string;
  intensity?: number;
  timestamp: number;
  isLoadingMessage?: boolean;
}

export interface PersonaAttributes {
  friendly: number;
  kind: number;
  strong: number;
  annoyed: number;
  kinky: number;
  sexy: number;
  amorous: number;
  horny: number;
  forward: number;
  cursing: number;
  naughty: number;
  foulLanguage: number;
  dirtyTalk: number;
  seductive: number;
  approachable: number;
  direct: number;
  secretive: number;
  rude: number;
  needy: number;
  dominant: number;
  submissive: number;
  dynamic: 'friend' | 'family' | 'stranger' | 'partner' | 'spouse' | 'slave' | 'master';
  gender: 'male' | 'female' | 'transgender_m2f' | 'transgender_f2m' | 'non_binary';
  orientation: 'straight' | 'gay' | 'lesbian' | 'bisexual' | 'asexual' | 'pansexual';
  age: number;
}

export interface TalentPortfolio {
  clothed: string[];
  underwear: string[];
  fullFrontal: string[];
  explicit: string[];
  chosenErotic: string[];
}

export interface NeuralTalent {
  id: string;
  trueName: string;
  streetName: string;
  idNumber: string;
  address: string;
  bankAccount: {
    bank: string;
    branchCode: string;
    accountNumber: string;
    accountType: string;
  };
  physical: {
    weight: string;
    height: string;
    hairColor: string;
    eyeColor: string;
    breastSize: string;
  };
  preferences: {
    fantasies: string;
    abilities: string;
    likes: string;
    dislikes: string;
    noGoZones: string;
    noGoActions: string;
  };
  portfolio: TalentPortfolio;
  status: 'pending' | 'active' | 'suspended';
  rating: number;
  currentLocation?: { lat: number; lng: number };
}

export interface Booking {
  id: string;
  talentId: string;
  userId: string;
  timestamp: number;
  duration: number; // minutes
  totalAmount: number;
  travelFee: number;
  status: 'requested' | 'accepted' | 'paid' | 'in_progress' | 'completed' | 'cancelled';
  meetingPoint?: string;
  uberStatus?: string;
  userLocation?: { lat: number; lng: number };
  talentLocation?: { lat: number; lng: number };
}

export interface FinancialRecord {
  id: string;
  date: string;
  type: 'income' | 'expense' | 'payout';
  amount: number;
  description: string;
  category: 'Service' | 'Uber' | 'Security' | 'Platform' | 'Vetting';
  talentId?: string;
  bookingId?: string;
}

export interface ImageSettings {
  width: number;
  height: number;
  aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4';
}

export interface UserSettings {
  userId: string;
  dob: string;
  isConsentGiven: boolean;
  isRegistered: boolean;
  isVetted: boolean;
  enableAutoVoice: boolean;
  enableAutoImage: boolean;
  enableSFX: boolean;
  preferredVoice: string; 
  voiceProvider: 'native' | 'gemini';
  voiceId?: string;
  unlockedLevel: number;
  personaConfig?: Partial<Record<PersonaType, PersonaAttributes>>;
  imageSettings?: ImageSettings;
}

export interface APIResponse {
  status: 'ok' | 'blocked' | 'review' | 'error';
  reply?: string;
  session_id?: string;
}
