function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { message: 'Method not allowed' });

  // TODO: Verify webhook signature if iKhokha provides one.
  // For now we accept and acknowledge.
  // You should persist webhook events to a DB (Supabase/Firebase/Postgres) for a real platform.
  try {
    return json(res, 200, { ok: true });
  } catch (e) {
    return json(res, 500, { ok: false, error: String(e) });
  }
}
