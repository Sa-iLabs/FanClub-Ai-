function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return json(res, 405, { message: 'Method not allowed' });

  const ref = (req.query?.ref || '').toString();
  if (!ref) return json(res, 400, { status: 'unknown', message: 'Missing ref' });

  // This endpoint is intentionally conservative: without official iKhokha status docs here,
  // we return "pending" unless a webhook confirms "paid".
  // If you have a status lookup endpoint from iKhokha, set IKHOKHA_STATUS_ENDPOINT and we will call it.
  try {
    const { IKHOKHA_STATUS_ENDPOINT, IKHOKHA_APPID, IKHOKHA_SECRET } = process.env;
    if (!IKHOKHA_STATUS_ENDPOINT) {
      return json(res, 200, { status: 'pending', raw: { ref, note: 'No IKHOKHA_STATUS_ENDPOINT configured; rely on webhook.' } });
    }

    if (!IKHOKHA_APPID || !IKHOKHA_SECRET) {
      return json(res, 500, { status: 'unknown', message: 'Server misconfigured: missing IKHOKHA_APPID/IKHOKHA_SECRET' });
    }

    const url = `${IKHOKHA_STATUS_ENDPOINT}?ref=${encodeURIComponent(ref)}`;
    const upstream = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json', 'IK-APPID': IKHOKHA_APPID.trim() } });
    const data = await upstream.json().catch(() => ({}));

    if (!upstream.ok) return json(res, upstream.status, { status: 'unknown', raw: data });

    // Normalize a few common shapes
    const paid = data?.status === 'paid' || data?.paid === true || data?.paymentStatus === 'paid';
    const failed = data?.status === 'failed' || data?.paymentStatus === 'failed';
    const pending = data?.status === 'pending' || data?.paymentStatus === 'pending';

    return json(res, 200, { status: paid ? 'paid' : failed ? 'failed' : pending ? 'pending' : 'unknown', raw: data });
  } catch (e) {
    return json(res, 500, { status: 'unknown', message: 'Server error', error: String(e) });
  }
}
