import crypto from 'crypto';

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { message: 'Method not allowed' });

  try {
    const { IKHOKHA_APPID, IKHOKHA_SECRET, IKHOKHA_ENDPOINT } = process.env;

    if (!IKHOKHA_APPID || !IKHOKHA_SECRET) {
      return json(res, 500, { message: 'Server misconfigured: missing IKHOKHA_APPID/IKHOKHA_SECRET' });
    }

    const endpoint = IKHOKHA_ENDPOINT || 'https://api.ikhokha.com/paylink/create';

    const bodyStr = JSON.stringify(req.body || {});
    const signature = crypto.createHmac('sha256', IKHOKHA_SECRET).update(bodyStr).digest('base64');

    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'IK-APPID': IKHOKHA_APPID.trim(),
        'IK-SIGN': signature.trim()
      },
      body: bodyStr
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return json(res, upstream.status, { message: 'iKhokha error', error: data });
    }

    return json(res, 200, data);
  } catch (e) {
    return json(res, 500, { message: 'Server error', error: String(e) });
  }
}
