function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { message: 'Method not allowed' });

  try {
    const { OPENROUTER_API_KEY, OPENROUTER_API_URL } = process.env;
    if (!OPENROUTER_API_KEY) {
      return json(res, 500, { message: 'Server misconfigured: missing OPENROUTER_API_KEY' });
    }

    const url = OPENROUTER_API_URL || 'https://openrouter.ai/api/v1/chat/completions';
    const payload = req.body || {};

    const upstream = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        // Optional: OpenRouter recommends these for attribution
        'HTTP-Referer': process.env.PUBLIC_APP_URL || '',
        'X-Title': process.env.PUBLIC_APP_NAME || 'FanClub-Ai'
      },
      body: JSON.stringify(payload)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return json(res, upstream.status, data);

    return json(res, 200, data);
  } catch (e) {
    return json(res, 500, { message: 'Server error', error: String(e) });
  }
}
